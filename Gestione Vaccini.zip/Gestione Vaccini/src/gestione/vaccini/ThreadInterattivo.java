/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.vaccini;
import java.io.*;
/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    ListaPuntiVaccinazione l;

    public ThreadInterattivo(ListaPuntiVaccinazione l) {
        this.l = l;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("1. Elimina Prenotazioni\n");
        System.out.print("2. Stampa vaccinati per regione\n");
        System.out.print("3. Stampa report\n");
        System.out.print("4. Uscita\n");
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
       
    public void run(){
        try{
            int scelta;
            String nomeFile;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("File Punti di Vaccinazione: ");
            nomeFile = bf.readLine();
            l.caricapuntivaccinazione(nomeFile);
            System.out.print("File Prenotati: ");
            nomeFile = bf.readLine();
            l.caricaprenotati(nomeFile);
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        int eta;
                        System.out.print("Inserisci età: ");
                        eta = Integer.parseInt(bf.readLine());
                        l.eliminaprenotati(eta);
                        break;
                    case 2:
                        String regione;
                        System.out.print("Inserisci regione: ");
                        regione = bf.readLine();
                        l.stampavaccinati(regione);
                        break;
                    case 3:
                        l.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente nel menu\n");
                }
            }            
            }catch(Exception e){
        }
        
    }
    
}
