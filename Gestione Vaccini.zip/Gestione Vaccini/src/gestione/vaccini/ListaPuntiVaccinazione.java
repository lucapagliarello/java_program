/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.vaccini;
import java.util.*;
import java.io.*;
/**
 *
 * @author pagli
 */
public class ListaPuntiVaccinazione {
    private LinkedList<PuntiVaccinazione> lista;
    private String PuntoEtaMediaMax;

    public ListaPuntiVaccinazione() {
        lista = new LinkedList();
    }
    
    public synchronized void caricapuntivaccinazione(String nomefile){
        String id;
        String nome;
        String indirizzo;
        String regione;
        int numMaxVaccinazioni;
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            id = bf.readLine();
            while(id != null) {
                nome = bf.readLine();
                indirizzo = bf.readLine();
                regione = bf.readLine();
                numMaxVaccinazioni = Integer.parseInt(bf.readLine());
                lista.add(new PuntiVaccinazione(id, nome, indirizzo, regione, numMaxVaccinazioni));
                
                id = bf.readLine();
            }
            bf.close();
        } catch(Exception e){
        }
    }
    
    public synchronized void caricaprenotati(String nomefile){
        String nome;
        String id;
        String cf;
        int eta;
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            nome = bf.readLine();
            while(nome != null) {
                id = bf.readLine();
                cf = bf.readLine();
                eta = Integer.parseInt(bf.readLine());
                for(PuntiVaccinazione p: lista){
                    if(p.getId().equals(id) && p.numPrenotati() != p.getNumMaxVaccinazioni()){
                        p.addPrenotati(new Prenotati(nome, cf, eta));
                    }
                }
                nome = bf.readLine();
            }
            bf.close();
        } catch(Exception e){
        }
    } 
    
    public synchronized void eliminaprenotati(int eta){
        for(PuntiVaccinazione pv: lista){
            pv.eliminaprenotati(eta);
        }
    }
    
    public synchronized void stampavaccinati(String regione) {
        int totale = 0;
        for(PuntiVaccinazione pv: lista){
            if(pv.getRegione().equals(regione))
                totale += pv.numPrenotati();
        }
        System.out.println("Numero totale di vaccinati: " + totale);
    }
    
    public synchronized void puntovaccinazioneEtaMediaAlta(){
        float max = -1;
        for(PuntiVaccinazione pv: lista){
            if(pv.etaMediaVaccinati() > max){
                max = pv.etaMediaVaccinati();
                PuntoEtaMediaMax = pv.getNome();
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Il punto vaccinazione con eta media piu alta e': " + PuntoEtaMediaMax);
    }
}
