/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.vaccini;
import java.util.*;
/**
 *
 * @author pagli
 */
public class PuntiVaccinazione {
    private String id;
    private String nome;
    private String indirizzo;
    private String regione;
    private int numMaxVaccinazioni;
    private LinkedList<Prenotati> elencoPrenotati;

    public PuntiVaccinazione(String id, String nome, String indirizzo, String regione, int numMaxVaccinazioni) {
        this.id = id;
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.regione = regione;
        this.numMaxVaccinazioni = numMaxVaccinazioni;
        elencoPrenotati = new LinkedList();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getRegione() {
        return regione;
    }

    public void setRegione(String regione) {
        this.regione = regione;
    }

    public int getNumMaxVaccinazioni() {
        return numMaxVaccinazioni;
    }

    public void setNumMaxVaccinazioni(int numMaxVaccinazioni) {
        this.numMaxVaccinazioni = numMaxVaccinazioni;
    } 
    
    public int numPrenotati(){
        return elencoPrenotati.size();
    }
    
    public void addPrenotati(Prenotati p){
        elencoPrenotati.add(p);
    }
    
    public void eliminaprenotati(int eta){
        for(Prenotati p: elencoPrenotati) {
            if(p.getEta() < eta)
                elencoPrenotati.remove(p);
        }
    }
    
    public float etaMediaVaccinati(){
        int somma = 0;
        for(Prenotati p:  elencoPrenotati){
            somma += p.getEta();
        }
        return somma/elencoPrenotati.size();
    }
}
