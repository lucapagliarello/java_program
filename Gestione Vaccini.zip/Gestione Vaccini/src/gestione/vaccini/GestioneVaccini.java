/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.vaccini;

/**
 *
 * @author pagli
 */
public class GestioneVaccini {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ListaPuntiVaccinazione lista = new ListaPuntiVaccinazione();
        
        ThreadReport tr = new ThreadReport(lista);
        ThreadInterattivo ti = new ThreadInterattivo(lista);
        
        ti.start();
        tr.start();
    }
    
}
