/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.vaccini;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private ListaPuntiVaccinazione l;

    public ThreadReport(ListaPuntiVaccinazione l) {
        this.l = l;
    }
    
    public void run(){
        try{
            while(true){
                l.puntovaccinazioneEtaMediaAlta();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
