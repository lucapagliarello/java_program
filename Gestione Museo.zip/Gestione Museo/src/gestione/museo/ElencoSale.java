/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.museo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class ElencoSale {
    private LinkedList<Sala> listaSale;
    private String TipologiaMax;
    
    public ElencoSale(){
        listaSale = new LinkedList<>();
    }
    
    public synchronized void caricasale(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String nome;
            int codiceSala;
            String periodoStorico;
            String collocazione;
            
            nome = bf.readLine();
            while(nome != null){
                codiceSala = Integer.parseInt(bf.readLine());
                periodoStorico = bf.readLine();
                collocazione = bf.readLine();
                
                listaSale.add(new Sala(nome, codiceSala, periodoStorico, collocazione));
                nome = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaopere(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            int codiceSala;
            int codiceOpera;
            String nomeAutore;
            String tipologia;
            float stimaValore;
            
            codiceSala = Integer.parseInt(bf.readLine());
            while(codiceSala != 0){
                codiceOpera = Integer.parseInt(bf.readLine());
                nomeAutore = bf.readLine();
                tipologia = bf.readLine();
                stimaValore = Float.parseFloat(bf.readLine());             
                
                if(tipologia.equals("statue")){
                    for(Sala s: listaSale)
                        s.addOpera(new Opera(codiceOpera, nomeAutore, tipologia, stimaValore));
                }
                
                codiceSala = Integer.parseInt(bf.readLine());
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void eliminaopera(int codiceS, int codiceO) throws NoOpere{
        for(Sala s: listaSale){
            if(s.getCodiceSala() == codiceS){
                if(s.eliminaopera(codiceO)){
                    System.out.println("Opera eliminata con successo");  
                    break;
                } else
                    throw new NoOpere();
            }
        }
    }
    
    public synchronized void stampavaloreopere(String autore){
        float totale = 0;
        for(Sala s: listaSale){
            totale += s.stampavalore(autore);
        }
        System.out.println("Valore totale opere dell'autore: " + totale);
    }
    
    public synchronized void generaReport(){
        int max = 0;
        for(Sala s: listaSale){
            if(s.tipologiamaxInteger() > max){
                max = s.tipologiamaxInteger();
                TipologiaMax = s.tipologiamaxString();
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Tipologia piu presente e': " + TipologiaMax);
    }
}
