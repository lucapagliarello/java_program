/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.museo;

/**
 *
 * @author pagli
 */
public class Opera {
    private int codiceOpera;
    private String nomeAutore;
    private String tipologia;
    private float stimaValore;

    public Opera(int codiceOpera, String nomeAutore, String tipologia, float stimaValore) {
        this.codiceOpera = codiceOpera;
        this.nomeAutore = nomeAutore;
        this.tipologia = tipologia;
        this.stimaValore = stimaValore;
    }

    public int getCodiceOpera() {
        return codiceOpera;
    }

    public void setCodiceOpera(int codiceOpera) {
        this.codiceOpera = codiceOpera;
    }

    public String getNomeAutore() {
        return nomeAutore;
    }

    public void setNomeAutore(String nomeAutore) {
        this.nomeAutore = nomeAutore;
    }

    public String getTipologia() {
        return tipologia;
    }

    public void setTipologia(String tipologia) {
        this.tipologia = tipologia;
    }

    public float getStimaValore() {
        return stimaValore;
    }

    public void setStimaValore(float stimaValore) {
        this.stimaValore = stimaValore;
    }

    @Override
    public String toString() {
        return "Opera{" + "codiceOpera=" + codiceOpera + ", nomeAutore=" + nomeAutore + ", tipologia=" + tipologia + ", stimaValore=" + stimaValore + '}';
    }
    
    
}
