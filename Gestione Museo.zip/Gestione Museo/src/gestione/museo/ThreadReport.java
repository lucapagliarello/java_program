/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.museo;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private ElencoSale s;

    public ThreadReport(ElencoSale s) {
        this.s = s;
    }
    
    public void run(){
        try{
            while(true){
                s.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
}
