/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.museo;

/**
 *
 * @author pagli
 */
public class GestioneMuseo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ElencoSale s = new ElencoSale();
        ThreadInterattivo ti = new ThreadInterattivo(s);
        ThreadReport tr = new ThreadReport(s);
        
        tr.setDaemon(true);
        ti.start();
        tr.start();
    }
    
}
