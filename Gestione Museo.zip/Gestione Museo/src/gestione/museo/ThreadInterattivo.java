/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.museo;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    private ElencoSale s;

    public ThreadInterattivo(ElencoSale s) {
        this.s = s;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         
                         1. Elimina un'opera da una sala
                         2. Stampa la somma totale del valore delle opere di un autore presenti nel museo
                         3. Stampa la tipologia di opera piu' presente nel museo
                         4. Uscita
                         """);
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            int scelta = -1;
            
            System.out.print("Nome File Sale: ");
            nomefile = bf.readLine();
            s.caricasale(nomefile);
            
            System.out.print("Nome File Opere: ");
            nomefile = bf.readLine();
            s.caricaopere(nomefile);
            
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        int codiceSala, codiceOpera;
                        System.out.print("Codice Sala: ");
                        codiceSala = Integer.parseInt(bf.readLine());
                        System.out.print("Codice Opera: ");
                        codiceOpera = Integer.parseInt(bf.readLine());
                        
                        s.eliminaopera(codiceSala, codiceOpera);
                        break;
                    case 2:
                        String autore;
                        System.out.print("Nome autore: ");
                        autore = bf.readLine();
                        
                        s.stampavaloreopere(autore);
                        break;
                    case 3:
                        s.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente in elenco");
                }
            }
        }catch(Exception e){
        }
    }    
}
