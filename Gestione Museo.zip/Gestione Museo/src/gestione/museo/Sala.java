/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.museo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 *
 * @author pagli
 */
public class Sala {
    private String nome;
    private int codiceSala;
    private String periodoStorico;
    private String collocazione;
    private LinkedList<Opera> listaOpere;

    public Sala(String nome, int codice, String periodoStorico, String collocazione) {
        this.nome = nome;
        this.codiceSala = codice;
        this.periodoStorico = periodoStorico;
        this.collocazione = collocazione;
        listaOpere = new LinkedList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodiceSala() {
        return codiceSala;
    }

    public void setCodiceSala(int codice) {
        this.codiceSala = codice;
    }

    public String getPeriodoStorico() {
        return periodoStorico;
    }

    public void setPeriodoStorico(String periodoStorico) {
        this.periodoStorico = periodoStorico;
    }

    public String getCollocazione() {
        return collocazione;
    }

    public void setCollocazione(String collocazione) {
        this.collocazione = collocazione;
    }
    
    public void addOpera(Opera o){
        listaOpere.add(o);
    }

    public LinkedList<Opera> getListaOpere() {
        return listaOpere;
    }
    
    
    
    public boolean eliminaopera(int codiceO){
        for(Iterator<Opera> it = listaOpere.iterator(); it.hasNext();){
            if(it.next().getCodiceOpera() == codiceO){
                it.remove();
                return true;
            }
        }
        return false;
    }
    
    public float stampavalore(String autore){
        float somma = 0.0F;
        for(Opera o: listaOpere){
            if(o.getNomeAutore().equals(autore)){
                somma += o.getStimaValore();
            }
        }
        return somma;
    }
    
    public int tipologiamaxInteger(){
        Map<String,Integer> contOpere = new HashMap<>();
        for(Opera o: listaOpere)
            contOpere.put(o.getTipologia(), contOpere.getOrDefault(o.getTipologia(), 0) + 1);
        String tipologiaMax1 = null;
        int max = 0;
        
        for(Map.Entry<String,Integer> entry : contOpere.entrySet()){
            if(entry.getValue() > max){
                tipologiaMax1 = entry.getKey();
                max = entry.getValue();
            }
        }
        return max;
    }
    
    public String tipologiamaxString(){
        Map<String,Integer> contOpere = new HashMap<>();
        for(Opera o: listaOpere)
            contOpere.put(o.getTipologia(), contOpere.getOrDefault(o.getTipologia(), 0) + 1);
        String tipologiaMax = null;
        int max = 0;
        
        for(Map.Entry<String,Integer> entry : contOpere.entrySet()){
            if(entry.getValue() > max){
                tipologiaMax = entry.getKey();
                max = entry.getValue();
            }
        }
        return tipologiaMax;
    }

    @Override
    public String toString() {
        return "Sala{" + "nome=" + nome + ", codice=" + codiceSala + ", periodoStorico=" + periodoStorico + ", collocazione=" + collocazione + '}';
    }  
    
}
