/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prodotti;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Prodotto {
    private String id;
    private String descrizione;
    private float peso;
    private float volume;
    private LinkedList<Registrazione> elencoRegistrazioni;

    public Prodotto(String id, String descrizione, float peso, float volume) {
        this.id = id;
        this.descrizione = descrizione;
        this.peso = peso;
        this.volume = volume;
        elencoRegistrazioni = new LinkedList();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }

    public LinkedList<Registrazione> getElencoRegistrazioni() {
        return elencoRegistrazioni;
    }

    public void setElencoRegistrazioni(LinkedList<Registrazione> elencoRegistrazioni) {
        this.elencoRegistrazioni = elencoRegistrazioni;
    }
    
    public void addRegistrazione(Registrazione r){
        elencoRegistrazioni.add(r);
    }
    
    public int PercentualeMinDifettosi(){
        int somma = 0;
        int sommadifettosa = 0;
        int percentuale = 0;
        for(Registrazione r: elencoRegistrazioni){
            somma += r.getNumpezzi();
            sommadifettosa = r.getNumPezziDifettosi();
        }
        return sommadifettosa/somma;
    }
    
    public void cancellaRegistrazioni(String data) throws NoRegistrazioni{
        int contatore = 0;
        for(Iterator<Registrazione> it = elencoRegistrazioni.iterator(); it.hasNext();){
            if(it.next().getData().compareTo(data) == 0){
                it.remove();
                contatore++;
            }
        }
        if(contatore == 0)
            throw new NoRegistrazioni();
    }
    
    public void pesoprodotto(String data){
        float totale = 0.0F;
        for(Registrazione r: elencoRegistrazioni){
            if(r.getData().compareTo(data) == 0){
                totale = peso * r.getNumpezzi();
            }
        }
        System.out.println("Il peso complessivo e': " + totale);
    }
    
    public float volumecomplessivo(){
        float totale = 0.0F;
        int somma = 0;
        for(Registrazione r: elencoRegistrazioni){
            somma += r.getNumpezzi();
        }
        return totale = somma*volume;
    }

    @Override
    public String toString() {
        return "Prodotto{" + "id=" + id + ", descrizione=" + descrizione + ", peso=" + peso + ", volume=" + volume + ", elencoRegistrazioni=" + elencoRegistrazioni + '}';
    }
    
    
    
    
}
