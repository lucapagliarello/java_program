/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prodotti;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private ElencoProdotti p;

    public ThreadReport(ElencoProdotti p) {
        this.p = p;
    }
    
    public void run(){
        try{
            while(true){
                p.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
