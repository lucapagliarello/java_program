/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.prodotti;

/**
 *
 * @author pagli
 */
public class GestioneProdotti {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ElencoProdotti lista = new ElencoProdotti();
        ThreadInterattivo ti = new ThreadInterattivo(lista);
        ThreadReport tr = new ThreadReport(lista);
        
        tr.setDaemon(true);
        
        ti.start();
        tr.start();
    }
    
}
