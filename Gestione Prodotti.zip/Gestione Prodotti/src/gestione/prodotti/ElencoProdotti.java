/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prodotti;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pagli
 */
public class ElencoProdotti {
    private LinkedList<Prodotto> listaProdotti;
    private String ProdottoMin;
    private String ProdottoMax;

    public ElencoProdotti() {
        listaProdotti = new LinkedList();
    }
    
    public synchronized void caricaprodotti(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            
            String id;
            String descrizione;
            float peso;
            float volume;
            
            id = bf.readLine();
            while(id != null){
                descrizione = bf.readLine();
                peso = Float.parseFloat(bf.readLine());
                volume = Float.parseFloat(bf.readLine());
                
                listaProdotti.add(new Prodotto(id, descrizione, peso, volume));
                id = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaregistrazioni(String nomefile, int np){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            
            String id;
            String data;
            int numpezzi;
            int numpezzidif;
            
            id = bf.readLine();
            while(id != null){
                data = bf.readLine();
                numpezzi = Integer.parseInt(bf.readLine());
                numpezzidif = Integer.parseInt(bf.readLine());
                
                for(Prodotto p: listaProdotti){
                    if(p.getId().equals(id) && numpezzi > np){
                        p.addRegistrazione(new Registrazione(data, numpezzi, numpezzidif));
                        break;
                    }
                }
                
                id = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void stampaprodotto(){
        int min = -1;
        for(Prodotto p: listaProdotti){
            if(p.PercentualeMinDifettosi() < min){
                min = p.PercentualeMinDifettosi();
                ProdottoMin = p.getId();
            }
        }
        System.out.println("Il prodotto con resa maggiore e': " + ProdottoMin);        
    }
    
    public synchronized void cancellaregistrazioni(String data){
        int cont = 0;
        for(Prodotto p: listaProdotti){
            try {
                p.cancellaRegistrazioni(data);
            } catch (NoRegistrazioni e) {
                System.out.println("Nessuna Registrazione Presente");
            }
        }
    }
    
    public synchronized void pesoprodotto(String id, String data){
        for(Prodotto p: listaProdotti){
            if(p.getId().equals(id))
                p.pesoprodotto(data);
        }
    }
    
    public synchronized void generaReport(){
        float max = 0.0F;
        for(Prodotto p: listaProdotti){
            if(p.volumecomplessivo() > max){
                max = p.volumecomplessivo();
                ProdottoMax = p.getId();
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Prodotto che occupa maggior volume complessivo: " + ProdottoMax);
    }
}
