/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prodotti;

/**
 *
 * @author pagli
 */
public class Registrazione {
    private String data;
    private int numpezzi;
    private int numPezziDifettosi;

    public Registrazione(String data, int numpezzi, int numPezziDifettosi) {
        this.data = data;
        this.numpezzi = numpezzi;
        this.numPezziDifettosi = numPezziDifettosi;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getNumpezzi() {
        return numpezzi;
    }

    public void setNumpezzi(int numpezzi) {
        this.numpezzi = numpezzi;
    }

    public int getNumPezziDifettosi() {
        return numPezziDifettosi;
    }

    public void setNumPezziDifettosi(int numPezziDifettosi) {
        this.numPezziDifettosi = numPezziDifettosi;
    }

    @Override
    public String toString() {
        return "Registrazione{" + "data=" + data + ", numpezzi=" + numpezzi + ", numPezziDifettosi=" + numPezziDifettosi + '}';
    }
    
    
}
