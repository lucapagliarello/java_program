/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prodotti;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    ElencoProdotti p;

    public ThreadInterattivo(ElencoProdotti p) {
        this.p = p;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("MENU\n" +
                "1. Stampa il prodotto con resa maggiore\n" +
                "2. Cancella le registrazioni di una certa data da tutti i prodotti\n" +
                "3. Determina il peso complessivo dei pezzi prodotti dato l'id e la data\n" +
                "4. Determina il prodotto che occupa maggiore volume complessivo\n" +
                "5. Uscita\n");
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile;
            int numpezzi, scelta;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Inserisci nome del file contenente la lista dei prodotti: ");
            nomefile = bf.readLine();
            p.caricaprodotti(nomefile);
            System.out.print("Inserisci nome del file contenente le registrazioni: ");
            nomefile = bf.readLine();
            System.out.print("Inserisci un numero di pezzi di soglia: ");
            numpezzi = Integer.parseInt(bf.readLine());
            p.caricaregistrazioni(nomefile, numpezzi);
            
            while((scelta = menu(bf)) != 5){
                switch(scelta){
                    case 1:
                        p.stampaprodotto();
                        break;
                    case 2:
                        String data;
                        System.out.print("Inserisci data: ");
                        data = bf.readLine();
                        p.cancellaregistrazioni(data);
                        break;
                    case 3:
                        String identificativo, d;
                        System.out.print("Inserisci id: ");
                        identificativo = bf.readLine();
                        System.out.print("Inserisci data: ");
                        d = bf.readLine();
                        p.pesoprodotto(identificativo, d);
                        break;
                    case 4:
                        p.stampaReport();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Voce non presente nel menu'\n");
                }
            }
        }catch(Exception e){
        }
    }
    
}
