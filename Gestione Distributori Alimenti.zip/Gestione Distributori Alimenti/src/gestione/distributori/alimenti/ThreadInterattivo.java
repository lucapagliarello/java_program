/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.distributori.alimenti;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    Distributori d;

    public ThreadInterattivo(Distributori d) {
        this.d = d;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         1. Stampa il numero di distributori in cui un dato alimento e' presente con un num di pezzi minore di N
                         2. Decrementa di N il numero di pezzi dell'alimento presente nel distributore
                         3. Stampa il distributore con valore piu' alto
                         4. Uscita
                         """);
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile1, nomefile2;
            int numpezzi, scelta;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Nome file distributori: ");
            nomefile1 = bf.readLine();
            d.caricadistributori(nomefile1);
            System.out.print("Nome file alimenti: ");
            nomefile2 = bf.readLine();
            System.out.print("Numero di pezzi di soglia: ");
            numpezzi = Integer.parseInt(bf.readLine());
            d.caricaalimenti(nomefile2, numpezzi);            
            
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        System.out.print("Codice alimento: ");
                        String codiceA = bf.readLine();
                        System.out.print("Numero di pezzi N: ");
                        int N = Integer.parseInt(bf.readLine());
                        d.stampadistributori(codiceA, N);
                        break;
                    case 2:
                        System.out.print("Id distributore: ");
                        int cd = Integer.parseInt(bf.readLine());
                        System.out.print("Codice alimento: ");
                        String ca = bf.readLine();
                        System.out.print("Di quanto vuoi decrementare il numero di pezzi? ");
                        int N1 = Integer.parseInt(bf.readLine());
                        d.decrementoalimento(cd, ca, N1);
                        break;
                    case 3:
                        d.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente");
                }
            }
        }catch(Exception e){
        }
    }
}
