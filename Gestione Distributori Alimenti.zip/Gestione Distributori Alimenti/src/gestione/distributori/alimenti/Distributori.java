/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.distributori.alimenti;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Distributori {
    private LinkedList<Distributore> listaDistributori;
    private Distributore Dmax;
    
    public Distributori(){
        listaDistributori = new LinkedList<>();
    }
    
    public synchronized void caricadistributori(String file){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(file));
            int id;
            String indirizzo;
            int tipo;
            int capienzaMax;
            
            id = Integer.parseInt(bf.readLine());
            while(id != 0){
                indirizzo = bf.readLine();
                tipo = Integer.parseInt(bf.readLine());
                capienzaMax = Integer.parseInt(bf.readLine());
                
                listaDistributori.add(new Distributore(id, indirizzo, tipo, capienzaMax));
                id = Integer.parseInt(bf.readLine());
                        
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaalimenti(String file, int soglia){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(file));
            int id;
            String codice;
            String descrizione;
            float prezzo;
            int numpezzi;
            
            codice = bf.readLine();
            while(codice != null){
                descrizione = bf.readLine();
                prezzo = Float.parseFloat(bf.readLine());
                numpezzi = Integer.parseInt(bf.readLine());
                id = Integer.parseInt(bf.readLine());
                
                if(numpezzi > soglia){
                    for(Distributore d: listaDistributori){
                        if(d.getId() == id)
                            d.addAlimento(new Alimento(codice, descrizione, prezzo, numpezzi));
                    }
                }
                
                codice = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void stampadistributori(String codiceA, int N){
        int totale = 0;
        for(Distributore d: listaDistributori){
            totale += d.totalealimenti(codiceA, N);
        }
        System.out.println("Numero di distributori: " + totale);
    }
    
    public synchronized void decrementoalimento(int cd, String ca, int N){
        for(Distributore d: listaDistributori){
            if(d.getId() == cd)
                d.decrementoalimento(ca, N);
        }
    }
    
    public synchronized void generaReport(){
        float max = 0.0F;
        for(Distributore d: listaDistributori){
            if(d.valorealimenti() > max){
                max = d.valorealimenti();
                Dmax = d;
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Distributore con valore piu alto: " + Dmax);
    }
    
}
