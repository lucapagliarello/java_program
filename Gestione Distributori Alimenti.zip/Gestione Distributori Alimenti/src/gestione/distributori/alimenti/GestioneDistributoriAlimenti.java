/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.distributori.alimenti;

/**
 *
 * @author pagli
 */
public class GestioneDistributoriAlimenti {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Distributori d = new Distributori();
        ThreadInterattivo ti = new ThreadInterattivo(d);
        ThreadReport tr = new ThreadReport(d);
        
        tr.setDaemon(true);
        ti.start();
        tr.start();
    }
    
}
