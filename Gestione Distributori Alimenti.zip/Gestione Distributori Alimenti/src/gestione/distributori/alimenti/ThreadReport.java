/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.distributori.alimenti;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private Distributori d;

    public ThreadReport(Distributori d) {
        this.d = d;
    }
    
    public void run(){
        try{
            while(true){
                d.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
