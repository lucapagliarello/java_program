/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.distributori.alimenti;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Distributore {
    private int id;
    private String indirizzo;
    private int tipo;
    private int capienzaMax;
    private LinkedList<Alimento> listaAlimenti;

    public Distributore(int id, String indirizzo, int tipo, int capienzaMax) {
        this.id = id;
        this.indirizzo = indirizzo;
        this.tipo = tipo;
        this.capienzaMax = capienzaMax;
        listaAlimenti = new LinkedList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public int getTipo() {
        return tipo;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getCapienzaMax() {
        return capienzaMax;
    }

    public void setCapienzaMax(int capienzaMax) {
        this.capienzaMax = capienzaMax;
    }
    
    public void addAlimento(Alimento a){
        listaAlimenti.add(a);
    }
    
    public int totalealimenti(String codiceA, int N){
        int somma = 0;
        for(Alimento a: listaAlimenti){
            if(a.getCodice().equals(codiceA) && a.getNumpezzi() < N)
                somma++;
        }
        return somma;
    }
    
    public void decrementoalimento(String ca, int N){
        int numpezzi = 0;
        for(Iterator<Alimento> it = listaAlimenti.iterator(); it.hasNext() ;){
            Alimento a = it.next();
            if(a.getCodice().equals(ca)){
                if(a.getNumpezzi() > 0)
                    numpezzi = a.getNumpezzi() - N;
                else
                    it.remove();
            }
        }
    }
    
    public float valorealimenti(){
        float totale = 0.0F;
        for(Alimento a: listaAlimenti){
            totale += a.getNumpezzi()*a.getPrezzo();
        }
        return totale;
    }

    @Override
    public String toString() {
        return "Distributore{" + "id=" + id + ", indirizzo=" + indirizzo + ", tipo=" + tipo + ", capienzaMax=" + capienzaMax + '}';
    }
    
    
}
