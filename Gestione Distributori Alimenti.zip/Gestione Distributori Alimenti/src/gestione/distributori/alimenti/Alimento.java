/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.distributori.alimenti;

/**
 *
 * @author pagli
 */
public class Alimento {
    private String codice;
    private String descrizione;
    private float prezzo;
    private int numpezzi;

    public Alimento(String codice, String descrizione, float prezzo, int numpezzi) {
        this.codice = codice;
        this.descrizione = descrizione;
        this.prezzo = prezzo;
        this.numpezzi = numpezzi;
    }

    public String getCodice() {
        return codice;
    }

    public void setCodice(String codice) {
        this.codice = codice;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public int getNumpezzi() {
        return numpezzi;
    }

    public void setNumpezzi(int numpezzi) {
        this.numpezzi = numpezzi;
    }

    @Override
    public String toString() {
        return "Alimento{" + "codice=" + codice + ", descrizione=" + descrizione + ", prezzo=" + prezzo + ", numpezzi=" + numpezzi + '}';
    }
    
    
}
