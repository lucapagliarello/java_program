/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.punti.fedelta;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Clienti {
    private LinkedList<Cliente> listaClienti;
    private Cliente ClienteMax;
    private Cliente ClienteMin;
    
    public Clienti(){
        listaClienti = new LinkedList<Cliente>();
    }
    
    public synchronized void caricaclienti(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String cf;
            String nome;
            String datascadenza;
            
            cf = bf.readLine();
            while(cf != null){
                nome = bf.readLine();
                datascadenza = bf.readLine();
                
                listaClienti.add(new Cliente(cf, nome, datascadenza));
                cf = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaacquisti(String nomefile, String data){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String cf;
            String codice;
            String dataAcquisto;
            float importo;
            
            cf = bf.readLine();
            while(cf != null){
                codice = bf.readLine();
                dataAcquisto = bf.readLine();
                importo = Float.parseFloat(bf.readLine());
                
                if(dataAcquisto.compareTo(data) > 0){
                    for(Cliente c: listaClienti){
                        if(c.getCf().equals(cf))
                            c.addAcquisto(new Acquisto(codice, dataAcquisto, importo));
                    }
                }
                cf = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void stampaclienti(int N, float P){
        for(Cliente c: listaClienti){
            if(c.acquistiNP(N, P))
                System.out.println(c.getCf());
        }
    }
    
    public synchronized void eliminaacquisti(String cf, String data){
        for(Cliente c: listaClienti){
            if(c.getCf().equals(cf))
                c.eliminaacquisti(data);
        }
    }
    
    public synchronized void stampacliente(){
        for(Cliente c: listaClienti){
            System.out.println("Cliente: " + c.getNome() + "Totale punti: " + c.stampapunti());
        }
    }
    
    public synchronized void generaReport(){
        float min = Float.MAX_VALUE;
        float max = 0.0F;
        
        for(Cliente c: listaClienti){
            if(c.sommaimporto() > max){
                max = c.sommaimporto();
                ClienteMax = c;
            }
            if(c.sommaimporto() < min){
                min = c.sommaimporto();
                ClienteMin = c;
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Cliente con spesa maggiore: " + ClienteMax.getCf());
        System.out.println("Cliente con spesa minore: " + ClienteMin.getCf());
        
    }
}
