/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.punti.fedelta;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    Clienti c;

    public ThreadInterattivo(Clienti c) {
        this.c = c;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         1. Stampa i clienti che hanno effettuato almeno N acquisti di importo superiore a P
                         2. Elimina gli acquisti realizzati da un cliente prima di una certa data
                         3. Stampa il totale dei punti per ogni cliente (5 punti per ogni 10 euro)
                         4. Stampa il cliente che ha speso di piu e quello che ha speso di meno
                         5. Uscita
                         """);
        
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile1, nomefile2, data;
            int scelta;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            
            System.out.print("Nome file clienti: ");
            nomefile1 = bf.readLine();
            System.out.print("Nome file acquisti: ");
            c.caricaclienti(nomefile1);
            nomefile2 = bf.readLine();
            System.out.print("Inserire data di soglia (aaaammgg): ");
            data = bf.readLine();
            c.caricaacquisti(nomefile1, data);
            
            while((scelta = menu(bf)) != 5){
                switch(scelta){
                    case 1:
                        System.out.print("Numero N di acquisti: ");
                        int N = Integer.parseInt(bf.readLine());
                        System.out.print("Importo P di soglia: ");
                        float P = Float.parseFloat(bf.readLine());
                        c.stampaclienti(N, P);
                        break;
                    case 2:
                        System.out.print("CF: ");
                        String cf = bf.readLine();
                        System.out.print("Data: ");
                        String dataSoglia = bf.readLine();
                        c.eliminaacquisti(cf, dataSoglia);
                        break;
                    case 3:
                        c.stampacliente();
                        break;
                    case 4:
                        c.stampaReport();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Voce non presente in elenco");
                }
            }
        }catch(Exception e){
        }
    }
    
}
