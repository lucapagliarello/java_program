/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.punti.fedelta;

/**
 *
 * @author pagli
 */
public class Acquisto {
    private String codice;
    private String dataAcquisto;
    private float importo;

    public Acquisto(String codice, String dataAcquisto, float importo) {
        this.codice = codice;
        this.dataAcquisto = dataAcquisto;
        this.importo = importo;
    }

    public String getCodice() {
        return codice;
    }

    public void setCodice(String codice) {
        this.codice = codice;
    }

    public String getDataAcquisto() {
        return dataAcquisto;
    }

    public void setDataAcquisto(String dataAcquisto) {
        this.dataAcquisto = dataAcquisto;
    }

    public float getImporto() {
        return importo;
    }

    public void setImporto(float importo) {
        this.importo = importo;
    }

    @Override
    public String toString() {
        return "Acquisto{" + "codice=" + codice + ", dataAcquisto=" + dataAcquisto + ", importo=" + importo + '}';
    }
    
    
}
