/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.punti.fedelta;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Cliente {
    private String cf;
    private String nome;
    private String datascadenza;
    private LinkedList<Acquisto> listaAcquisti;

    public Cliente(String cf, String nome, String datascadenza) {
        this.cf = cf;
        this.nome = nome;
        this.datascadenza = datascadenza;
        listaAcquisti = new LinkedList<Acquisto>();
    }

    public String getCf() {
        return cf;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDatascadenza() {
        return datascadenza;
    }

    public void setDatascadenza(String datascadenza) {
        this.datascadenza = datascadenza;
    }
    
    public void addAcquisto(Acquisto a){
        listaAcquisti.add(a);
    }
    
    public boolean acquistiNP(int N, float P){
        int contatore = 0;
        for(Acquisto a: listaAcquisti){
            if(a.getImporto() > P)
                contatore++;
        }
        return contatore > N;
    }
    
    public void eliminaacquisti(String data){
        for(Iterator<Acquisto> it = listaAcquisti.iterator(); it.hasNext();){
            if(it.next().getDataAcquisto().compareTo(data) < 0)
                it.remove();
        }
    }
    
    public int stampapunti(){
        int punti = 0;
        for(Acquisto a: listaAcquisti){
            punti += (a.getImporto()/10)*5;
        }
        return punti;
    }
    
    public float sommaimporto(){
        float somma = 0.0F;
        for(Acquisto a: listaAcquisti){
            somma += a.getImporto();
        }
        return somma;
    }

    @Override
    public String toString() {
        return "Cliente{" + "cf=" + cf + ", nome=" + nome + ", datascadenza=" + datascadenza + '}';
    }
    
    
}
