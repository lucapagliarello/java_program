/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.immobili;

/**
 *
 * @author pagli
 */
public class UnitaImmobiliare {
    private String id;
    private String descrizione;
    private String indirizzo;
    private String cfproprietario;
    private float m2;
    private int numerovani;
    private float prezzo;

    public UnitaImmobiliare(String id, String descrizione, String indirizzo, String cfproprietario, float m2, int numerovani, float prezzo) {
        this.id = id;
        this.descrizione = descrizione;
        this.indirizzo = indirizzo;
        this.cfproprietario = cfproprietario;
        this.m2 = m2;
        this.numerovani = numerovani;
        this.prezzo = prezzo;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getCfproprietario() {
        return cfproprietario;
    }

    public void setCfproprietario(String cfproprietario) {
        this.cfproprietario = cfproprietario;
    }

    public float getM2() {
        return m2;
    }

    public void setM2(float m2) {
        this.m2 = m2;
    }

    public int getNumerovani() {
        return numerovani;
    }

    public void setNumerovani(int numerovani) {
        this.numerovani = numerovani;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(int prezzo) {
        this.prezzo = prezzo;
    }

    @Override
    public String toString() {
        return "UnitaImmobiliare{" + "id=" + id + ", descrizione=" + descrizione + ", indirizzo=" + indirizzo + ", codice fiscale proprietario=" + cfproprietario + ", metri quadri=" + m2 + ", numero vani=" + numerovani + ", prezzo=" + prezzo + '}';
    }
}
