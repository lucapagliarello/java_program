/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.immobili;
import java.io.*;

/**
 *
 * @author pagli
 */
public class GestioneImmobili {
    
    public static int menu(BufferedReader bf) throws Exception{
        System.out.println("Menu'");
        System.out.println("1. Inserisci immobile\n");
        System.out.println("2. Stampa gli immobili in vendita di una data persona\n");
        System.out.println("3. Stampa il numero totale di immobili in vendita\n");
        System.out.println("4. Stampa il giro di affari dell'agenzia\n");
        System.out.println("5. Rimuovi immobile\n");
        System.out.println("6. Uscita");
        int scelta = Integer.parseInt(bf.readLine());
        return scelta;
    }
    
    public static int creaimmobile(BufferedReader bf, UnitaImmobiliare[] i, int numI) throws Exception {
        System.out.println("ID: ");
        String ID = bf.readLine();
        System.out.println("DESCRIZIONE: ");
        String descrizione = bf.readLine();
        System.out.println("INDIRIZZO: ");
        String indirizzo = bf.readLine();
        System.out.println("CODICE FISCALE PROPRIETARIO: ");
        String cf = bf.readLine();
        System.out.println("METRI QUADRATI: ");
        float m2 = Float.parseFloat(bf.readLine());
        System.out.println("NUMERO DI VANI: ");
        int numvani = Integer.parseInt(bf.readLine());
        System.out.println("PREZZO DI VENDITA: ");
        float prezzo = Float.parseFloat(bf.readLine());
        
        for(int j=0; j<numI; j++){
            if(i[j].getId().equals(ID))
                throw new ImmobilePresente();
        }
        
        i[numI] = new UnitaImmobiliare(ID, descrizione, indirizzo, cf, m2, numvani, prezzo);
        numI++;
        return numI;
    }
    
    public static void stampaimmobili(BufferedReader bf, UnitaImmobiliare[] i, int numI) throws Exception {
        System.out.println("Inserisci il codice fiscale della persona: ");
        String cf = bf.readLine();
        
        for(int j=0; j<numI; j++){
            if(i[j].getCfproprietario().equals(cf))
                System.out.println(i[j]);
        }
    }
    
    public static void giroaffari(UnitaImmobiliare[] i, int numI) throws Exception {
        float somma = 0.0F;
        
        for(int j=0; j<numI; j++){
            somma += i[j].getPrezzo();
        }
        System.out.println("Il giro di affari e': " + somma);
    }
    
    public static int rimuoviimmobile(BufferedReader bf, UnitaImmobiliare[] i, int numI) throws Exception {
        System.out.println("Id: ");
        String id = bf.readLine();
        
        for(int j=0; j<numI; j++){
            if(i[j].getId().equals(id)){
                i[j] = i[numI - 1];
                i[numI - 1] = null;
                numI--;
                break;
            }
        }
        return numI;
    }
    

    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        int scelta, N;
        UnitaImmobiliare[] elencoimmobili;
        int numimmobili = 0;
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        
        System.out.println("Inserisci il numero N di immobili da gestire: ");
        N = Integer.parseInt(bf.readLine());
        
        elencoimmobili = new UnitaImmobiliare[N];
        
        while((scelta = menu(bf)) != 6){
            switch(scelta){
                case 1:
                    numimmobili = creaimmobile(bf, elencoimmobili, numimmobili);
                    break;
                case 2:
                    stampaimmobili(bf, elencoimmobili, numimmobili);
                    break;
                case 3:
                    System.out.println(numimmobili);
                    break;
                case 4:
                    giroaffari(elencoimmobili, numimmobili);
                    break;
                case 5:
                    numimmobili = rimuoviimmobile(bf, elencoimmobili, numimmobili);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Voce non presente in elenco.");
            }
        }
    }
    
}
