/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.immobili;

/**
 *
 * @author pagli
 */
public class Appartamento extends UnitaImmobiliare {
    private int piano;
    private int numpostoauto;

    public Appartamento(int piano, int numpostoauto, String id, String descrizione, String indirizzo, String cfproprietario, float m2, int numerovani, int prezzo) {
        super(id, descrizione, indirizzo, cfproprietario, m2, numerovani, prezzo);
        this.piano = piano;
        this.numpostoauto = numpostoauto;
    }

    public int getPiano() {
        return piano;
    }

    public void setPiano(int piano) {
        this.piano = piano;
    }

    public int getNumpostoauto() {
        return numpostoauto;
    }

    public void setNumpostoauto(int numpostoauto) {
        this.numpostoauto = numpostoauto;
    }

    @Override
    public String toString() {
        return "Appartamento{" + super.toString() + "piano=" + piano + ", numero posto auto=" + numpostoauto + '}';
    }
}
