/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.immobili;

/**
 *
 * @author pagli
 */
public class VillaSingola extends UnitaImmobiliare {
    private int numlivelli;
    private float m2giardino;
    private boolean piscina;

    public VillaSingola(int numlivelli, float m2giardino, boolean piscina, String id, String descrizione, String indirizzo, String cfproprietario, float m2, int numerovani, int prezzo) {
        super(id, descrizione, indirizzo, cfproprietario, m2, numerovani, prezzo);
        this.numlivelli = numlivelli;
        this.m2giardino = m2giardino;
        this.piscina = piscina;
    }

    public int getNumlivelli() {
        return numlivelli;
    }

    public void setNumlivelli(int numlivelli) {
        this.numlivelli = numlivelli;
    }

    public float getM2giardino() {
        return m2giardino;
    }

    public void setM2giardino(float m2giardino) {
        this.m2giardino = m2giardino;
    }

    public boolean isPiscina() {
        return piscina;
    }

    public void setPiscina(boolean piscina) {
        this.piscina = piscina;
    }

    @Override
    public String toString() {
        return "VillaSingola{" + super.toString() + "numlivelli=" + numlivelli + ", m2giardino=" + m2giardino + '}';
    }
}
