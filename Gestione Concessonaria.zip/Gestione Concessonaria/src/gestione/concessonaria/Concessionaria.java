/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessonaria;

/**
 *
 * @author pagli
 */
public class Concessionaria {
    private String nome;
    private Veicolo[] elencoveicoli;
    private int numveicoli;

    public Concessionaria(String nome, int N) {
        this.nome = nome;
        elencoveicoli = new Veicolo[N];
        numveicoli = 0;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumveicoli() {
        return numveicoli;
    }

    public void setNumveicoli(int numveicoli) {
        this.numveicoli = numveicoli;
    }
    
    
    public void aggiungiVeicolo(Veicolo v) throws ConcessionariaPiena{
        if(elencoveicoli.length == numveicoli)
            throw new ConcessionariaPiena();
        elencoveicoli[numveicoli] = v;
        numveicoli++;
    }
    
    public void trovaVeicoli(int costo){
        for(int i=0; i<numveicoli; i++){
            if(elencoveicoli[i].getPrezzo() <= costo)
                System.out.println(elencoveicoli[i]);
        }
    }
    
    public int costo(){
        int somma = 0;
        for(int i=0; i<numveicoli; i++){
            somma += elencoveicoli[i].getPrezzo();
        }
        return somma;
    }
    
    public void rimuoviVeicolo(String targa){
        for(int i=0; i<numveicoli; i++){
            if(elencoveicoli[i].getTarga().equals(targa)){
                elencoveicoli[i] = elencoveicoli[numveicoli--];
                elencoveicoli[numveicoli--] = null;
                numveicoli--;
                return;
            }
        }
    }
    
    public float MaxVeicoli(){
        float max = 0;
        
        for(int i=0; i<numveicoli; i++){
            if(elencoveicoli[i].getPrezzo() > max)
                max = elencoveicoli[i].getPrezzo();
        }
        return max;
    }
}
