/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessonaria;

/**
 *
 * @author pagli
 */
public class Veicolo implements Comparable {
    private String targa;
    private String marca;
    private String modello;
    private int cilindrata;
    private int annoimmatricolazione;
    private int prezzo;

    public Veicolo(String targa, String marca, String modello, int cilindrata, int annoimmatricolazione, int prezzo) {
        this.targa = targa;
        this.marca = marca;
        this.modello = modello;
        this.cilindrata = cilindrata;
        this.annoimmatricolazione = annoimmatricolazione;
        this.prezzo = prezzo;
    }

    public String getTarga() {
        return targa;
    }

    public void setTarga(String targa) {
        this.targa = targa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModello() {
        return modello;
    }

    public void setModello(String modello) {
        this.modello = modello;
    }

    public int getCilindrata() {
        return cilindrata;
    }

    public void setCilindrata(int cilindrata) {
        this.cilindrata = cilindrata;
    }

    public int getAnnoimmatricolazione() {
        return annoimmatricolazione;
    }

    public void setAnnoimmatricolazione(int annoimmatricolazione) {
        this.annoimmatricolazione = annoimmatricolazione;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(int prezzo) {
        this.prezzo = prezzo;
    }

    @Override
    public String toString() {
        return "Veicolo{" + "marca=" + marca + ", modello=" + modello + ", cilindrata=" + cilindrata + ", annoimmatricolazione=" + annoimmatricolazione + ": prezzo=" + prezzo + '}';
    }
    
    @Override
    public int compareTo(Object o){
        return prezzo - ((Veicolo)o).prezzo;
    }
    
}
