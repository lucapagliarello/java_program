/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.concessonaria;
import java.io.*;

/**
 *
 * @author pagli
 */
public class GestioneConcessonaria {
    
    public static int menu(BufferedReader bf){
        int scelta = 0;
        System.out.println("MENU'\n");
        System.out.println("1. Crea nuova concessionaria\n");
        System.out.println("2. Aggiungi veicolo\n");
        System.out.println("3. Stampa concessionaria con piu' veicoli\n");
        System.out.println("4. Stampa concessionaria con autoveicolo piu' costoso\n");
        System.out.println("5. Rimuovi concessionaria\n");
        System.out.println("6. Uscita\n");
        System.out.println("Inserire la scelta---> ");
        try{
            scelta = Integer.parseInt(bf.readLine());
            return scelta;
        } catch(IOException | NumberFormatException e){
            System.out.println("");
        }
        return -1;
    }
    
    public static int aggiungiConcessionaria(BufferedReader bf, Concessionaria[] c, int numConcessionarie){
        String nome;
        int numVeicoli;
        
        try{
            System.out.println("Inserisci il nome della concessionaria: ");
            nome = bf.readLine();
            System.out.println("Inserisci il numero di veicoli presenti: ");
            numVeicoli = Integer.parseInt(bf.readLine());
            c[numConcessionarie] = new Concessionaria(nome, numVeicoli);
            numConcessionarie++;
            return numConcessionarie;
        } catch(Exception e){
            System.out.println("ERRORE");
            System.exit(-1);
        }
        return -1;
    }
    
    public static void aggiungiVeicolo(BufferedReader bf, Concessionaria[] c, int numConcessionarie) throws ConcessionariaPiena{
        String nome;
        String targa;
        String marca;
        String modello;
        int cilindrata;
        int annoimmatricolazione;
        int prezzo;
        int scelta;
        try{
            System.out.println("Inserisci il nome della concessionaria: ");
            nome = bf.readLine();
            for(int i=0; i<numConcessionarie; i++){
                if(c[i].getNome().equals(nome)){
                    System.out.println("Targa: ");
                    targa = bf.readLine();
                    System.out.println("Marca: ");
                    marca = bf.readLine();
                    System.out.println("Modello: ");
                    modello = bf.readLine();
                    System.out.println("Cilindrata: ");
                    cilindrata = Integer.parseInt(bf.readLine());
                    System.out.println("Anno immatricolazione: ");
                    annoimmatricolazione = Integer.parseInt(bf.readLine());
                    System.out.println("Prezzo: ");
                    prezzo = Integer.parseInt(bf.readLine());
                    
                    System.out.println("Digita 0 per inserire un'automobile, 1 per inserire un autocarro: ");
                    scelta = Integer.parseInt(bf.readLine());
                    if(scelta == 0){
                        System.out.println("Numero di porte: ");
                        int porte = Integer.parseInt(bf.readLine());
                        System.out.println("Numero di posti: ");
                        int posti = Integer.parseInt(bf.readLine());
                        c[i].aggiungiVeicolo(new Automobile(porte, posti, targa, marca, modello, cilindrata, annoimmatricolazione, prezzo));
                    } else {
                        System.out.println("Carico: ");
                        float carico = Float.parseFloat(bf.readLine());
                        c[i].aggiungiVeicolo(new Autocarro(carico, targa, marca, modello, cilindrata, annoimmatricolazione, prezzo));
                    }
                }
            }
        }catch(ConcessionariaPiena e){
            System.out.println("ERRORE! La concessionaria e' piena");
        } catch(Exception e){
            System.out.println("ERRORE! Inserimento non valido");
            System.exit(-1);
        }
    }
    
    public static void stampaconcessionariamaxveicoli(Concessionaria[] c, int numC){
        Concessionaria ConcMAX = null;
        int max = 0;
        for(int i=0; i<numC; i++){
            if(c[i].getNumveicoli() > max){
                max = c[i].getNumveicoli();
                ConcMAX = c[i];
            }
        }
        System.out.println(ConcMAX.getNome());
    }
    
    public static void stampaconcessionariaveicolocostoso(Concessionaria[] c, int numC) {
        Concessionaria ConcMAX = null;
        float max = 0.0F;
        for(int i=0; i<numC; i++){
            if(c[i].MaxVeicoli() > max){
                max = c[i].MaxVeicoli();
                ConcMAX = c[i];
            }
        }
        System.out.println(ConcMAX.getNome());
    }
    
    public static int rimuoviConcessionaria(BufferedReader bf, Concessionaria[] c, int numC){
        try {
            String nome;
            System.out.println("Inserisci il nome della concessionaria: ");
            nome = bf.readLine();
            for(int i=0; i<numC; i++){
                if(c[i].getNome().equals(nome)){
                    c[i] = c[numC--];
                    c[numC--] = null;
                    numC--;
                    break;
                }
            }
        } catch (Exception e) {
        }
        return numC;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Concessionaria[] elencoConcessionarie;
        int M = 0;
        int scelta = 0;
        int numConcessionarie = 0;
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Inserire il numero M di concessionarie da gestire: ");
        try{
            M = Integer.parseInt(bf.readLine());
        } catch(IOException | NumberFormatException e){
            System.out.println("");
        }
        
        elencoConcessionarie = new Concessionaria[M];
        
        while((scelta = menu(bf)) != 6){
            switch(scelta){
                case 1:
                    numConcessionarie = aggiungiConcessionaria(bf, elencoConcessionarie, numConcessionarie);
                    break;
                case 2:
                {
                    try {
                        aggiungiVeicolo(bf, elencoConcessionarie, numConcessionarie);
                    } catch (ConcessionariaPiena ex) {
                        System.out.println("Concessionaria piena!");
                    }
                }
                    break;
                case 3:
                    stampaconcessionariamaxveicoli(elencoConcessionarie, numConcessionarie);
                    break;
                case 4:
                    stampaconcessionariaveicolocostoso(elencoConcessionarie, numConcessionarie);
                    break;
                case 5:
                    numConcessionarie = rimuoviConcessionaria(bf, elencoConcessionarie, numConcessionarie);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Voce non contenuta nel menu'.");
            }
        }
    }
    
}
