/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessonaria;

/**
 *
 * @author pagli
 */
public class Autocarro extends Veicolo {
    private float carico;

    public Autocarro(float carico, String targa, String marca, String modello, int cilindrata, int annoimmatricolazione, int prezzo) {
        super(targa, marca, modello, cilindrata, annoimmatricolazione, prezzo);
        this.carico = carico;
    }

    public float getCarico() {
        return carico;
    }

    public void setCarico(float carico) {
        this.carico = carico;
    }

    @Override
    public String toString() {
        return "Autocarro{" + super.toString() + "carico=" + carico + '}';
    }
}
