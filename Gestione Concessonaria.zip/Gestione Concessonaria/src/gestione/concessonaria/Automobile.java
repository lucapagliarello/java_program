/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessonaria;

/**
 *
 * @author pagli
 */
public class Automobile extends Veicolo {
    private int numeroporte;
    private int numeroposti;

    public Automobile(int numeroporte, int numeroposti, String targa, String marca, String modello, int cilindrata, int annoimmatricolazione, int prezzo) {
        super(targa, marca, modello, cilindrata, annoimmatricolazione, prezzo);
        this.numeroporte = numeroporte;
        this.numeroposti = numeroposti;
    }

    public int getNumeroporte() {
        return numeroporte;
    }

    public void setNumeroporte(int numeroporte) {
        this.numeroporte = numeroporte;
    }

    public int getNumeroposti() {
        return numeroposti;
    }

    public void setNumeroposti(int numeroposti) {
        this.numeroposti = numeroposti;
    }

    @Override
    public String toString() {
        return "Automobile{" + super.toString() + "numeroporte=" + numeroporte + ", numeroposti=" + numeroposti + '}';
    }
}
