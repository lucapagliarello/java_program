/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessonaria;

/**
 *
 * @author pagli
 */
public class ConcessionariaPiena extends Exception {
    
}
