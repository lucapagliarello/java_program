/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.agenzia;

import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Compagnia {
    private String nome;
    private String indirizzo;
    private String nomereferente;
    private LinkedList<Cliente> listaClienti;

    public Compagnia(String nome, String indirizzo, String nomereferente) {
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.nomereferente = nomereferente;
        listaClienti = new LinkedList<Cliente>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }

    public String getNomereferente() {
        return nomereferente;
    }

    public void setNomereferente(String nomereferente) {
        this.nomereferente = nomereferente;
    }
    
    public void addCliente(Cliente c){
        listaClienti.add(c);
    }
    
    public boolean trovaCliente(String cf){
        for(Cliente cl: listaClienti){
            if(cl.getCf().equals(cf))
                return true;
        }
        return false;
    }
    
    public float sommatotale(String cf, String data){
        float somma = 0.0F;
        for(Cliente c: listaClienti){
            if(c.getDatascadenzaP().compareTo(data) > 0 && c.getCf().equals(cf))
                somma += c.getImportorataP();
        }
        return somma;
    }
    
    public int numeroclienti() {
        return listaClienti.size();
    }

    @Override
    public String toString() {
        return "Compagnia{" + "nome=" + nome + ", indirizzo=" + indirizzo + ", nomereferente=" + nomereferente + '}';
    }
    
    
}
