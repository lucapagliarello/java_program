/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.agenzia;

/**
 *
 * @author pagli
 */
public class GestioneAgenzia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Compagnie c = new Compagnie();
        ThreadInterattivo ti = new ThreadInterattivo(c);
        ThreadReport tr = new ThreadReport(c);
        
        tr.setDaemon(true);
        ti.start();
        tr.start();
    }
    
}
