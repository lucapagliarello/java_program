/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.agenzia;

/**
 *
 * @author pagli
 */
public class Cliente {
    private String cf;
    private String nome;
    private String IDpolizza;
    private String datascadenzaP;
    private float importorataP;

    public Cliente(String cf, String nome, String IDpolizza, String datascadenzaP, float importorataP) {
        this.cf = cf;
        this.nome = nome;
        this.IDpolizza = IDpolizza;
        this.datascadenzaP = datascadenzaP;
        this.importorataP = importorataP;
    }

    public String getCf() {
        return cf;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIDpolizza() {
        return IDpolizza;
    }

    public void setIDpolizza(String IDpolizza) {
        this.IDpolizza = IDpolizza;
    }

    public String getDatascadenzaP() {
        return datascadenzaP;
    }

    public void setDatascadenzaP(String datascadenzaP) {
        this.datascadenzaP = datascadenzaP;
    }

    public float getImportorataP() {
        return importorataP;
    }

    public void setImportorataP(float importorataP) {
        this.importorataP = importorataP;
    }

    @Override
    public String toString() {
        return "Cliente{" + "cf=" + cf + ", nome=" + nome + ", IDpolizza=" + IDpolizza + ", datascadenzaP=" + datascadenzaP + ", importorataP=" + importorataP + '}';
    }
    
    
}
