/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.agenzia;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    Compagnie c;

    public ThreadInterattivo(Compagnie c) {
        this.c = c;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         1. Stioula una nuova polizza con un cliente
                         2. Stampa la somma di tutte le rate delle polizze di un cliente la cui data di scadenza è maggiore di quella fornita
                         3. Stampa la compagnia con il maggior numero di clienti
                         4. Uscita
                         """);
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile1, nomefile2;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            int scelta;
        
            System.out.print("Nome file compagnie assicurative: ");
            nomefile1 = bf.readLine();
            c.caricacompagnie(nomefile1);
            
            System.out.print("Nome file clienti: ");
            nomefile2 = bf.readLine();
            c.caricaclienti(nomefile2);
            
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        System.out.print("Nome compagnia assicurativa: ");
                        String compagnia = bf.readLine();
                        c.nuovocliente(compagnia);
                        break;
                    case 2:
                        System.out.print("Codice fiscale: ");
                        String cf = bf.readLine();
                        System.out.print("Data (aaaammgg): ");
                        String data = bf.readLine();
                        c.sommarate(cf, data);
                        break;
                    case 3:
                        c.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente in elenco. ");
                }
            }
            }catch(Exception e){
            }
    }
}
