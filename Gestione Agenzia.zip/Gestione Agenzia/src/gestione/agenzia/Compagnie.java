/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.agenzia;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Compagnie {
    private LinkedList<Compagnia> listaCompagnie;
    private Compagnia MaxC;
    
    public Compagnie(){
        listaCompagnie = new LinkedList<Compagnia>();
    }
    
    public synchronized void caricacompagnie(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String nome;
            String indirizzo;
            String nomereferente;
            
            nome = bf.readLine();
            while(nome != null){
                indirizzo = bf.readLine();
                nomereferente = bf.readLine();
                
                listaCompagnie.add(new Compagnia(nome, indirizzo, nomereferente));
                nome = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaclienti(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String nome;
            String cf;
            String nomeCliente;
            String IDpolizza;
            String datascadenzaP;
            float importorataP;
            
            nome = bf.readLine();
            while(nome != null){
                cf = bf.readLine();
                nomeCliente = bf.readLine();
                IDpolizza = bf.readLine();
                datascadenzaP = bf.readLine();
                importorataP = Float.parseFloat(bf.readLine());
                
                for(Compagnia c: listaCompagnie){
                    if(c.getNome().equals(nome))
                        c.addCliente(new Cliente(cf, nomeCliente, IDpolizza, datascadenzaP, importorataP));
                }
                
                nome = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void nuovocliente(String compagnia) throws ClientePresente{
        try{
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            for(Compagnia c: listaCompagnie){
                if(c.getNome().equals(compagnia)) {
                    String codicefiscale;
                    String nomeCliente;
                    String IDpolizza;
                    String datascadenzaP;
                    float importorataP;
                    System.out.print("Codice fiscale: ");
                    codicefiscale = bf.readLine();
                    System.out.print("Nome: ");
                    nomeCliente = bf.readLine();
                    System.out.print("Id polizza: ");
                    IDpolizza = bf.readLine();
                    System.out.print("Data scadenza polizza: ");
                    datascadenzaP = bf.readLine();
                    System.out.print("Importo rata polizza: ");
                    importorataP = Float.parseFloat(bf.readLine());
                    
                    Cliente cliente = new Cliente(codicefiscale, nomeCliente, IDpolizza, datascadenzaP, importorataP);
                    c.addCliente(cliente);
                    
                    if(!c.trovaCliente(cliente.getCf()))
                        break;
                    else
                        throw new ClientePresente();                    
                }
            }
        }catch(Exception e){
        }
    }
    
    public synchronized void sommarate(String cf, String data){
        float somma = 0.0F;
        for(Compagnia c: listaCompagnie){
            somma += c.sommatotale(cf, data);
        }
        System.out.println("Somma totale delle rate: " + somma);
    }
    
    public synchronized void generaReport(){
        int max = 0;
        for(Compagnia c: listaCompagnie){
            if(c.numeroclienti() > max){
                max = c.numeroclienti();
                MaxC = c;
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Compagnia con il maggior numero di clienti: " + MaxC.getNome());
    }
}
