/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.agenzia;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    Compagnie c;

    public ThreadReport(Compagnie c) {
        this.c = c;
    }
    
    public void run(){
        try{
            while(true){
                c.generaReport();
                Thread.sleep(5000);
            }
        }catch(Exception e){
        }
    }
}
