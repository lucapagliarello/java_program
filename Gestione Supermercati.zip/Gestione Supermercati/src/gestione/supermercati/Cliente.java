/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.supermercati;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Cliente {
    private String id;
    private String nome;
    private String indirizzo;
    private LinkedList<Acquisto> listaAcquisti;

    public Cliente(String id, String nome, String indirizzo) {
        this.id = id;
        this.nome = nome;
        this.indirizzo = indirizzo;
        listaAcquisti = new LinkedList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIndirizzo() {
        return indirizzo;
    }

    public void setIndirizzo(String indirizzo) {
        this.indirizzo = indirizzo;
    }
    
    public void addAcquisto(Acquisto a){
        listaAcquisti.add(a);
    }
    
    public void eliminaacquisti(float importo){
        for(Iterator<Acquisto> it = listaAcquisti.iterator(); it.hasNext();){
            if(it.next().isMerceConsegnata() && it.next().getImporto() < importo)
                it.remove();
        }
    }
    
    public boolean merceDaConsegnare(float importo, String data){
        float totale = 0.0F;
        for(Acquisto a: listaAcquisti){
            if(a.getData().equals(data) && !a.isMerceConsegnata())
                totale += a.getImporto();
        }
        if(totale >= importo)
            return false;
        else
            return true;
    }
    
    public float importototale(){
        float totale = 0.0F;
        for(Acquisto a: listaAcquisti){
            if(a.getData().compareTo("20200000") > 0 && a.getData().compareTo("20210000") < 0)
                totale += a.getImporto();
        }
        return totale;
    }

    @Override
    public String toString() {
        return "Cliente{" + "id=" + id + ", nome=" + nome + ", indirizzo=" + indirizzo + '}';
    }
    
    
}
