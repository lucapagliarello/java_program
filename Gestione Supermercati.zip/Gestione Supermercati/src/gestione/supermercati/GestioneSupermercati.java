/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.supermercati;

/**
 *
 * @author pagli
 */
public class GestioneSupermercati {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaClienti lc = new ListaClienti();
        ThreadInterattivo ti = new ThreadInterattivo(lc);
        ThreadReport tr = new ThreadReport(lc);
        
        tr.setDaemon(true);
        
        ti.start();
        tr.start();
    }
    
}
