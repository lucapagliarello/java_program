/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.supermercati;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class ListaClienti {
    private LinkedList<Cliente> elencoClienti;
    private String ClienteMax;
    
    public ListaClienti(){
        elencoClienti = new LinkedList<>();
    }
    
    public synchronized void caricaclienti(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String id;
            String nome;
            String indirizzo;
            
            id = bf.readLine();
            while(id != null){
                nome = bf.readLine();
                indirizzo = bf.readLine();
                
                elencoClienti.add(new Cliente(id, nome, indirizzo));
                id = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
   
    public synchronized void caricaacquisti(String nomefile, String data){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String id;
            String descrizione;
            String IdScontrino;
            float importo;
            String dataAcquisto;
            boolean merceConsegnata;
            
            id = bf.readLine();
            while(id != null){
                descrizione = bf.readLine();
                IdScontrino = bf.readLine();
                importo = Float.parseFloat(bf.readLine());
                dataAcquisto = bf.readLine();
                merceConsegnata = Boolean.parseBoolean(bf.readLine());
                
                for(Cliente c: elencoClienti){
                    if(dataAcquisto.compareTo(data) > 0 && c.getId().equals(id))
                        c.addAcquisto(new Acquisto(descrizione, IdScontrino, importo, dataAcquisto, merceConsegnata));
                }
                
                id = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void eliminaacquisti(float importo){
        for(Cliente c: elencoClienti){
            c.eliminaacquisti(importo);
        }
    }
    
    public synchronized void stampaclienti(float importo, String data){
        for(Cliente c: elencoClienti){
            if(c.merceDaConsegnare(importo, data))
                System.out.println(c.getId());
        }
    }
    
    public synchronized void generaReport(){
        float max = 0.0F;
        for(Cliente c: elencoClienti){
            if(c.importototale() > max){
                max = c.importototale();
                ClienteMax = c.getNome();
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Il cliente che ha speso di piu' nel 2020 e': " + ClienteMax);
    }
}
