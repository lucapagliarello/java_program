/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.supermercati;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private ListaClienti lc;

    public ThreadReport(ListaClienti lc) {
        this.lc = lc;
    }
    
    public void run(){
        try{
            while(true){
                lc.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
