/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.supermercati;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    ListaClienti lc;

    public ThreadInterattivo(ListaClienti lc) {
        this.lc = lc;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("MENU\n" +
                "1. Elimina gli acquisti avente un importo inferiore ad un valore X e che risulta gia consegnata\n" +
                "2. Dato un importo e una data, stampare i clienti a cui bisogna ancora consegnare per un importo maggiore di quello dato\n" +
                "3. Stampa il cliente che ha speso di piu' nel 2020\n" +
                "4. Uscita\n");
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try {
            String nomeFile, data;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            int scelta = -1;
            
            System.out.print("Nome file clienti: ");
            nomeFile = bf.readLine();
            lc.caricaclienti(nomeFile);
            
            System.out.print("Nome file acquisti:");
            nomeFile = bf.readLine();
            System.out.print("Inserisci una data di soglia: ");
            data = bf.readLine();
            lc.caricaacquisti(nomeFile, data);
            
            while((scelta = menu(bf)) != 4){
                switch(scelta) {
                    case 1:
                        float X;
                        System.out.print("Inserisci l'importo X di soglia: ");
                        X = Float.parseFloat(bf.readLine());
                        lc.eliminaacquisti(X);
                        break;
                    case 2:
                        float importoX;
                        System.out.print("Inserisci l'importo X di soglia: ");
                        importoX = Float.parseFloat(bf.readLine());       
                        String D;
                        System.out.print("Inserisci la data da considerare: ");
                        D = bf.readLine();
                        lc.stampaclienti(importoX, D);
                        break;
                    case 3:
                        lc.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente nel menu");
                }
            }
        } catch(Exception e){
        }
    }
}
