/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.supermercati;

/**
 *
 * @author pagli
 */
public class Acquisto {
    private String descrizione;
    private String IdScontrino;
    private float importo;
    private String data;
    private boolean merceConsegnata;

    public Acquisto(String descrizione, String IdScontrino, float importo, String data, boolean merceConsegnata) {
        this.descrizione = descrizione;
        this.IdScontrino = IdScontrino;
        this.importo = importo;
        this.data = data;
        this.merceConsegnata = merceConsegnata;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String getIdScontrino() {
        return IdScontrino;
    }

    public void setIdScontrino(String IdScontrino) {
        this.IdScontrino = IdScontrino;
    }

    public float getImporto() {
        return importo;
    }

    public void setImporto(float importo) {
        this.importo = importo;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public boolean isMerceConsegnata() {
        return merceConsegnata;
    }

    public void setMerceConsegnata(boolean merceConsegnata) {
        this.merceConsegnata = merceConsegnata;
    }

    @Override
    public String toString() {
        return "Acquisto{" + "descrizione=" + descrizione + ", IdScontrino=" + IdScontrino + ", importo=" + importo + ", data=" + data + ", merceConsegnata=" + merceConsegnata + '}';
    }
    
    
}
