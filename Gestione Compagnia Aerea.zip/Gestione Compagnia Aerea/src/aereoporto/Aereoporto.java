/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aereoporto;
import java.io.*;

/**
 *
 * @author pagli
 */
public class Aereoporto {
    
    public static int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("\n\n"
                         + "-2. Inserimento volo\n"
                         + "-1. Inserimento bagaglio\n"
                         + "1. Stampa lista voli da aeroporto\n"
                         + "2. Stampa peso bagagli\n"
                         + "3. Stampa voli con disponibilità posti\n"
                         + "4. Stampa aereo più leggero\n"
                         + "5. Uscita\n"
                         + "--> Inserire la scelta: ");
        try {
            scelta = Integer.parseInt(bf.readLine());
            
        } catch (Exception e) {
            System.out.println("Errore di I/O");
            System.exit(-1);
        }
        return scelta;
    }


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        Compagnia c = null;
        int scelta, N;
        
        System.out.print("Inserire il numero di voli gestiti dalla compagnia:");
        try {
            N = Integer.parseInt(bf.readLine());
            c = new Compagnia(N);
        } catch (Exception e) {
            System.out.println("Errore di I/O");
            System.exit(-1);
        }
        
        while((scelta = menu(bf)) != 5){
            switch(scelta){
                case -2: 
                    c.inserimentoVolo(bf);
                    break;
                case -1:
                    c.inserimentoBagaglio(bf);
                    break;
                case 1:
                    try {
                        System.out.print("Inserire il codice dell'aeroporto di partenza: ");
                        c.stampaVoliDaAeroporto(bf.readLine());
                    } catch (Exception e) {
                        System.out.println("Errore di I/O");
                        System.exit(-1);
                    }
                    break;
                case 2:
                     try {
                        System.out.print("Inserire il codice del volo: ");
                        c.pesoBagagli(bf.readLine());
                    } catch (Exception e) {
                        System.out.println("Errore di I/O");
                        System.exit(-1);
                    }
                    break;
                case 3:
                    c.voliConPostiDisponibili();
                    break;
                case 4:
                    c.aereoPiuLeggero();
                    break;             
            }
        }
    }
    
}
