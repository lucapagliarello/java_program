/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aereoporto;
import java.io.*;

/**
 *
 * @author pagli
 */
public class Compagnia {
    private Volo[] elencoVoli;
    private int numVoli;
    
    public Compagnia(int N){
        this.elencoVoli = new Volo[N];
        numVoli = 0;
    }
    
    public void inserimentoVolo(BufferedReader bf){
        String codiceVolo;
        int numPosti;
        int pesoBagagli;
        String codiceAeroportoPartenza;
        String codiceAeroportoArrivo;
        
        try {
            if (numVoli == elencoVoli.length){
                System.out.println("Elenco voli pieno!");
                return;
            }
                
            System.out.print("Codice volo: ");
            codiceVolo = bf.readLine();
            System.out.print("Numero posti: ");
            numPosti = Integer.parseInt(bf.readLine());
            System.out.print("Peso max bagagli: ");
            pesoBagagli = Integer.parseInt(bf.readLine());
            System.out.print("Codice aeroporto partenza: ");
            codiceAeroportoPartenza = bf.readLine();
            System.out.print("Codice aeroporto arrivo: ");
            codiceAeroportoArrivo = bf.readLine();
            
            elencoVoli[numVoli] = new Volo(codiceVolo, numPosti, pesoBagagli, codiceAeroportoPartenza, codiceAeroportoArrivo);
            numVoli++;       
        } catch (Exception e) {
            System.out.println("Errore di I/O");
            System.exit(-1);
        }
    }
    
    public void inserimentoBagaglio(BufferedReader bf){
        
        try {
            String codiceVolo;
            int peso;
            boolean daStiva;
            
            System.out.print("Codice volo: ");
            codiceVolo = bf.readLine();
            System.out.print("Peso bagaglio: ");
            peso = Integer.parseInt(bf.readLine());
            System.out.print("Da stiva?: ");
            daStiva = Boolean.parseBoolean(bf.readLine());
            
            for (int i = 0; i < numVoli; i++)
                if (elencoVoli[i].getCodiceVolo().equals(codiceVolo)){
                    elencoVoli[i].aggiungiBagaglio(peso, daStiva);
                    return;
                }
        } catch (Exception e) {
        }
        
    }
    
    public void stampaVoliDaAeroporto(String codiceAeroporto){
        
        for (int i = 0; i < numVoli; i++){
            if (elencoVoli[i].getCodiceAeroportoPartenza().equals(codiceAeroporto)){
                System.out.println(elencoVoli[i]);
            }     
        }
    }
    
    public void pesoBagagli(String codiceVolo){
        
        for (int i = 0;  i < numVoli; i++){
            if (elencoVoli[i].getCodiceVolo().equals(codiceVolo)){
                System.out.println("Peso bagagli a mano: " + elencoVoli[i].pesoBagagliMano());
                System.out.println("Peso bagagli in stiva: " + elencoVoli[i].pesoBagagliStiva());
                return;

            }
        }
    }
    
    public void voliConPostiDisponibili(){
        
        for (int i = 0; i < numVoli; i++){
            if (elencoVoli[i].disponibilitaPosti())
                System.out.println("Volo: " + elencoVoli[i].getCodiceVolo());
        }
    }
    
    public void aereoPiuLeggero(){
        float min = Float.MAX_VALUE;
        float peso;
        int imin = -1;
        
        
        for (int i = 0; i < numVoli; i++){
            peso = elencoVoli[i].pesoBagagliMano() + elencoVoli[i].pesoBagagliStiva();
            if (peso < min){
                min = peso;
                imin = i;
            }
        }
        System.out.println("L'aereo con peso minimo dei bagagli è: " + elencoVoli[imin]);
    }

}
