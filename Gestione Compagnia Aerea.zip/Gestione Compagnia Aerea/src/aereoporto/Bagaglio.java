/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aereoporto;

/**
 *
 * @author pagli
 */
public class Bagaglio {
    private float peso;
    private boolean daStiva;

    public Bagaglio(float peso, boolean daStiva) {
        this.peso = peso;
        this.daStiva = daStiva;
    }

    public boolean isDaStiva() {
        return daStiva;
    }

    public float getPeso() {
        return peso;
    }
    
    
}
