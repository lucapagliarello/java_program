/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aereoporto;

/**
 *
 * @author pagli
 */
public class Volo {
    private String codiceVolo;
    private int numPosti;
    private float pesoBagagli;
    private String codiceAeroportoPartenza;
    private String codiceAeroportoArrivo;
    private Passeggero[] elencoPasseggeri;
    private Bagaglio[] elencoBagagli;
    private int numPasseggeri, numBagagli;

    public Volo(String codiceVolo, int numPosti, float pesoBagagli, String codiceAeroportoPartenza, String codiceAeroportoArrivo) {
        this.codiceVolo = codiceVolo;
        this.numPosti = numPosti;
        this.pesoBagagli = pesoBagagli;
        this.codiceAeroportoPartenza = codiceAeroportoPartenza;
        this.codiceAeroportoArrivo = codiceAeroportoArrivo;
        this.numPasseggeri = 0;
        this.numBagagli = 0;
        this.elencoPasseggeri = new Passeggero[numPosti];
        this.elencoBagagli = new Bagaglio[numPosti];
    }  

    public String getCodiceAeroportoPartenza() {
        return codiceAeroportoPartenza;
    }

    public String getCodiceVolo() {
        return codiceVolo;
    }
    
    
    public String toString(){
        String str;
        
        str = "Codice volo: " + codiceVolo + ", Numero Posti: " + numPosti + ", Peso bagali: " + pesoBagagli + ", Aeroporto di paertenza: " + codiceAeroportoPartenza + ", Aeroporto di arrivo:" + codiceAeroportoArrivo;
        return str;
    }
    
    public float pesoBagagliMano(){
        float somma = 0.0F;
        
        for (int i = 0; i < numBagagli; i++){
            if (!elencoBagagli[i].isDaStiva())
                somma += elencoBagagli[i].getPeso();
        }
        return somma;
    }

    public float pesoBagagliStiva(){
        float somma = 0.0F;
        
        for (int i = 0; i < numBagagli; i++){
            if (elencoBagagli[i].isDaStiva())
                somma += elencoBagagli[i].getPeso();
        }
        return somma;
    }
    
    public boolean disponibilitaPosti(){
        return ((numPasseggeri / numPosti) < 0.6); 
    }
    
    public void aggiungiBagaglio(float peso, boolean daStiva){
        if (numBagagli == elencoBagagli.length){
            System.out.println("Non c'è più spazio per i bagagli");
            return;
        }
        elencoBagagli[numBagagli] = new Bagaglio(peso, daStiva);
        numBagagli++;
    }
}

