/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prestazioni.sanitarie;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    Prestazioni p;

    public ThreadReport(Prestazioni p) {
        this.p = p;
    }
    
    public void run(){
        try{
            while(true){
                p.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
