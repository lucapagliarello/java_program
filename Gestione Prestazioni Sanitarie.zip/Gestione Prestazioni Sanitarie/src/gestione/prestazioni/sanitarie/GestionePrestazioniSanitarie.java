/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.prestazioni.sanitarie;

/**
 *
 * @author pagli
 */
public class GestionePrestazioniSanitarie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Prestazioni p = new Prestazioni();
        ThreadInterattivo ti = new ThreadInterattivo(p);
        ThreadReport tr = new ThreadReport(p);
        
        tr.setDaemon(true);
        ti.start();
        tr.start();
    }
    
}
