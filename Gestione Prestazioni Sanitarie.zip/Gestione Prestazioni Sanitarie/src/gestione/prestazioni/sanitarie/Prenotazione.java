/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prestazioni.sanitarie;

/**
 *
 * @author pagli
 */
public class Prenotazione {
    private String nomePrenotato;
    private String cfPrenotato;
    private String data;

    public Prenotazione(String nomePrenotato, String cfPrenotato, String data) {
        this.nomePrenotato = nomePrenotato;
        this.cfPrenotato = cfPrenotato;
        this.data = data;
    }

    public String getNomePrenotato() {
        return nomePrenotato;
    }

    public void setNomePrenotato(String nomePrenotato) {
        this.nomePrenotato = nomePrenotato;
    }

    public String getCfPrenotato() {
        return cfPrenotato;
    }

    public void setCfPrenotato(String cfPrenotato) {
        this.cfPrenotato = cfPrenotato;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Prenotazione{" + "nomePrenotato=" + nomePrenotato + ", cfPrenotato=" + cfPrenotato + ", data=" + data + '}';
    }
    
    
}
