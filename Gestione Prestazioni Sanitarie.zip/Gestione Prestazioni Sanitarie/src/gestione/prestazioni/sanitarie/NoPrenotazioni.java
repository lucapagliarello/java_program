/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prestazioni.sanitarie;

/**
 *
 * @author pagli
 */
public class NoPrenotazioni extends Exception {
    
}
