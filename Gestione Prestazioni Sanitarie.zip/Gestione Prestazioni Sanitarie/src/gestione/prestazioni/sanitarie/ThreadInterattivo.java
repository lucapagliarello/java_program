/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prestazioni.sanitarie;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread{
    Prestazioni p;

    public ThreadInterattivo(Prestazioni p) {
        this.p = p;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         1. Stampa il costo totale delle prestazioni a carica di un prenotato
                         2. Cancella le prenotazioni effettuate prima del 2020
                         3. Stampa il ricavo totale delle prestazioni a carico del SSN nel 2023
                         4. Stampa le prestazioni piu e meno remunerativa nel 2024
                         5. Uscita
                         """);
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile1, nomefile2;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            int scelta;
            
            System.out.print("Nome file prestazioni: ");
            nomefile1 = bf.readLine();
            p.caricaprestazioni(nomefile1);
            System.out.print("Nome file prenotazioni: ");
            nomefile2 = bf.readLine();
            p.caricaprenotazioni(nomefile2);
            
            while((scelta = menu(bf)) != 5){
                switch(scelta){
                    case 1:
                        System.out.print("CF: ");
                        String cf = bf.readLine();
                        System.out.print("Data: ");
                        String data = bf.readLine();
                        p.costoprestazioni(cf, data);
                        break;
                    case 2:
                        p.cancellaprenotazioni();
                        break;
                    case 3:
                        p.ricavoprestazioniSSN();
                        break;
                    case 4:
                        p.stampaReport();
                    case 5:
                        return;
                    default:
                        System.out.println("Voce non presente");
                }
            }
        }catch(Exception e){
        
        }
    }
}
