/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prestazioni.sanitarie;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Prestazione {
    private String nome;
    private String descrizione;
    private float tariffa;
    private boolean SSN;
    private LinkedList<Prenotazione> listaPrenotazioni;

    public Prestazione(String nome, String descrizione, float tariffa, boolean SSN) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.tariffa = tariffa;
        this.SSN = SSN;
        listaPrenotazioni = new LinkedList<Prenotazione>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getTariffa() {
        return tariffa;
    }

    public void setTariffa(float tariffa) {
        this.tariffa = tariffa;
    }

    public boolean isSSN() {
        return SSN;
    }

    public void setSSN(boolean SSN) {
        this.SSN = SSN;
    }
    
    public void addPrenotazione(Prenotazione p){
        listaPrenotazioni.add(p);
    }
    
    public float costoprestazioni(String cf, String data){
        float somma = 0.0F;
        for(Prenotazione p: listaPrenotazioni){
            if(p.getCfPrenotato().equals(cf) && p.getData().compareTo(data) > 0){
                somma += tariffa;
            }
        }
        return somma;
    }
    
    public void cancellaprenotazioni() throws NoPrenotazioni{
        int contatore = 0;
        for(Iterator<Prenotazione> it = listaPrenotazioni.iterator(); it.hasNext();){
            if(it.next().getData().compareTo("20200000") < 0){
                it.remove();
                contatore++;
            }
        }
        if(contatore == 0)
            throw new NoPrenotazioni();
    }
    
    public float Data(){
        int contatore = 0;
        for(Prenotazione p: listaPrenotazioni){
            if(p.getData().compareTo("20230000") > 0 && p.getData().compareTo("20240000") < 0)
                contatore++;
        }
        return contatore*tariffa;
    }
    
    public float profitto(){
        int contatore = 0;
        for(Prenotazione p: listaPrenotazioni){
            if(p.getData().compareTo("20240000") > 0 && p.getData().compareTo("20250000") < 0)
                contatore++;
        }
        return contatore*tariffa;
    }

    @Override
    public String toString() {
        return "Prestazione{" + "nome=" + nome + ", descrizione=" + descrizione + ", tariffa=" + tariffa + ", SSN=" + SSN + '}';
    }
    
    
}
