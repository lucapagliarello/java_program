/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.prestazioni.sanitarie;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pagli
 */
public class Prestazioni {
    private LinkedList<Prestazione> listaPrestazioni;
    private Prestazione Pmax;
    private Prestazione Pmin;
    
    public Prestazioni(){
        listaPrestazioni = new LinkedList<Prestazione>();
    }
    
    public synchronized void caricaprestazioni(String file){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(file));
            String nome;
            String descrizione;
            float tariffa;
            boolean SSN;
            
            nome = bf.readLine();
            while(nome != null){
                descrizione = bf.readLine();
                tariffa = Float.parseFloat(bf.readLine());
                SSN = Boolean.parseBoolean(bf.readLine());
                
                listaPrestazioni.add(new Prestazione(nome, descrizione, tariffa, SSN));
                nome = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaprenotazioni(String file){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(file));
            String nome;
            String nomePrenotato;
            String cfPrenotato;
            String data;
            
            nomePrenotato = bf.readLine();
            while(nomePrenotato != null){
                cfPrenotato = bf.readLine();
                nome = bf.readLine();
                data = bf.readLine();
                
                for(Prestazione p: listaPrestazioni){
                    if(p.getNome().equals(nome))
                        p.addPrenotazione(new Prenotazione(nomePrenotato, cfPrenotato, data));
                } 
                nomePrenotato = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void costoprestazioni(String cf, String data){
        for(Prestazione p: listaPrestazioni){
            System.out.println("Prestazione: " + p.getNome() + "Costo totale: " + p.costoprestazioni(cf, data));
        }
    }
    
    public synchronized void cancellaprenotazioni(){
        int totale = 0;
        for(Prestazione p: listaPrestazioni){
            try {
                p.cancellaprenotazioni();
            } catch (NoPrenotazioni e) {
                System.out.println("Nessuna Prenotazione presente con tali caratteristiche");
            }
        }
    }
    
    public synchronized void ricavoprestazioniSSN(){
        float totale = 0.0F;
        for(Prestazione p: listaPrestazioni){
            if(p.isSSN())
                totale += p.Data();
        }
        System.out.println("Ricavo totale prestazioni a carico del SSN: " + totale);
    }
    
    public synchronized void generaReport(){
        float min = Float.MAX_VALUE;
        float max = 0.0F;
        for(Prestazione p: listaPrestazioni){
            if(p.profitto() > max){
                max = p.profitto();
                Pmax = p;
            }
            if(p.profitto() < min){
                min = p.profitto();
                Pmin = p;
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Prestazione piu remunerativa: " + Pmax);
        System.out.println("Prestazione meno remunerativa: " + Pmin);
    }
}
