/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.libreria;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Scaffali {
    private LinkedList<Scaffale> listascaffali;
    private Scaffale MaxS;
    
    public Scaffali(){
        listascaffali = new LinkedList<>();
    }
    
    public synchronized void caricascaffali(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            
            String tema;
            String descrizione;
            float sconto;
            
            tema = bf.readLine();
            while(tema != null){
                descrizione = bf.readLine();
                sconto = Float.parseFloat(bf.readLine());
                
                listascaffali.add(new Scaffale(tema, descrizione, sconto));
                tema = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricalibri(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            
            String tema;
            String codice;
            String autore;
            String titolo;
            float prezzo;
            String datapubblicazione;
            boolean disponibile;
            
            codice = bf.readLine();
            while(codice != null){
                tema = bf.readLine();
                autore = bf.readLine();
                titolo = bf.readLine();
                prezzo = Float.parseFloat(bf.readLine());
                datapubblicazione = bf.readLine();
                disponibile = Boolean.parseBoolean(bf.readLine());
                
                for(Scaffale s: listascaffali){
                    if(s.getTema().equals(tema)){
                        s.addLibro(new Libro(codice, autore, titolo, prezzo, datapubblicazione, disponibile));
                        break;
                    }
                    
                }
                codice = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void stampalibri(String autore, String data){
        int totale = 0;
        for(Scaffale s: listascaffali){
            totale += s.libri(autore, data);
        }
        System.out.println("Numero totale di libri: " + totale);
    }
    
    public synchronized void eliminalibri(float prezzo) throws NoLibriEliminati{
        int totale = 0;
        for(Scaffale s: listascaffali){
            totale += s.eliminalibro(prezzo);
        }
        if(totale == 0)
            throw new NoLibriEliminati();
    }
    
    public synchronized void generaReport(){
        float max = 0.0F;
        for(Scaffale s: listascaffali){
            if(s.prezzolibri() > max){
                max = s.prezzolibri();
                MaxS = s;
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Scaffale con prezzo medio dei libri maggiore: " + MaxS);
    }
    
    
}
