/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.libreria;
import java.util.LinkedList;
import java.io.*;

/**
 *
 * @author pagli
 */
public class GestioneScaffali {
    private LinkedList<Scaffale> elencoScaffali;
    private Scaffale sMAX;

    public GestioneScaffali() {
        elencoScaffali = new LinkedList<>();
    }
    
    public synchronized void leggiScaffali(String nomefile) {
        BufferedReader bf = null;
        try{
            bf = new BufferedReader(new FileReader(nomefile));
            String tema;
            String descrizione;
            float sconto;
            
            tema = bf.readLine();
            while(tema != null){
                descrizione = bf.readLine();
                sconto = Float.parseFloat(bf.readLine());
                elencoScaffali.add(new Scaffale(tema, descrizione, sconto));
                tema = bf.readLine(); /*viene fatto per verifica se nel file aperto vi sono ancora elementi da dover leggere*/
            }
            
            bf.close();
            
        } catch(Exception e){
        }

    }
    
    public synchronized void leggiLibri(String nomefile) throws TemaAssenteException {
        BufferedReader bf = null;
        try{
            bf = new BufferedReader(new FileReader(nomefile));
            String codice;
            String autore;
            String titolo;
            float prezzo;
            String data;
            String tema;
            boolean added = false;
            
            codice = bf.readLine();
            while(codice != null){
                tema = bf.readLine();
                autore = bf.readLine();
                titolo = bf.readLine();
                prezzo = Float.parseFloat(bf.readLine());
                data = bf.readLine();
                /*scorro la lista attraverso un "for each"-> prendere il primo elemento della lista e porlo uguale a s nel nostro caso*/
                for(Scaffale s: elencoScaffali){
                    if(s.getTema().equals(tema)){
                        s.addLibro(new Libro(codice, autore, titolo, prezzo, data));
                        added = true;
                        break;
                    } /*se il tema non dovesse essere presente l'eccezione da sollevare non dovrebbe 
                    essere sollevata adesso ma alla fine perché in questo punto non verrebbe controllato correttamente*/
                }
                
                if(!added)
                    throw new TemaAssenteException();
                codice = bf.readLine();
            }
            
            bf.close();
            
        } catch(Exception e){
        }

    }
        
    public synchronized void contaLibri(String autore, String data) {
        int totale = 0;
        for(Scaffale s: elencoScaffali){
            totale += s.contaLibri(autore, data);
        }
        System.out.println("Il numero totale di libri e': " + totale);
    }
    
    public synchronized void eliminaLibri(float prezzo) throws NessunLibroEliminato {
        int cont = 0;
        /*boolean eliminati = false;*/
        for(Scaffale s: elencoScaffali){
            cont += s.eliminaLibri(prezzo);
            /*eliminati = eliminati || s.eliminaLibri(prezzo); -> ALTRO MODO PER FARLO CON IL BOOLEANO*/
        }
        if(cont == 0)
            throw new NessunLibroEliminato();
    }
    
    public synchronized void generaReport(){
        float max = 0.0F;
        for(Scaffale s: elencoScaffali){
            if(s.prezzoMedioLibri() > max){
                max = s.prezzoMedioLibri();
                sMAX = s;
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Lo scaffale con prezzo medio piu alto e' :" + sMAX);
    }
    
    
}
