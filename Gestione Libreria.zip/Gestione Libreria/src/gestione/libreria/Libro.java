/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.libreria;

/**
 *
 * @author pagli
 */
public class Libro {
    private String codice;
    private String autore;
    private String titolo;
    private float prezzo;
    private String datapubblicazione;
    private boolean disponibile;

    public Libro(String codice, String autore, String titolo, float prezzo, String datapubblicazione, boolean disponibile) {
        this.codice = codice;
        this.autore = autore;
        this.titolo = titolo;
        this.prezzo = prezzo;
        this.datapubblicazione = datapubblicazione;
        this.disponibile = disponibile;
    }
    
    

    public String getCodice() {
        return codice;
    }

    public void setCodice(String codice) {
        this.codice = codice;
    }

    public String getAutore() {
        return autore;
    }

    public void setAutore(String autore) {
        this.autore = autore;
    }

    public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public String getDatapubblicazione() {
        return datapubblicazione;
    }

    public void setDatapubblicazione(String datapubblicazione) {
        this.datapubblicazione = datapubblicazione;
    }

    public boolean isDisponibile() {
        return disponibile;
    }

    public void setDisponibile(boolean disponibile) {
        this.disponibile = disponibile;
    }

    @Override
    public String toString() {
        return "Libro{" + "codice=" + codice + ", autore=" + autore + ", titolo=" + titolo + ", prezzo=" + prezzo + ", datapubblicazione=" + datapubblicazione + ", disponibile=" + disponibile + '}';
    }
    
    
}
