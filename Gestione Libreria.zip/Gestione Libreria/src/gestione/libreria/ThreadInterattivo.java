/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.libreria;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    Scaffali s;

    public ThreadInterattivo(Scaffali s) {
        this.s = s;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         1. Stampa il numero di libri pubblicati da un autore dopo una certa data
                         2. Elimina i libri con un dato prezzo
                         3. Stampa lo scaffale con prezzo medio di libri piu alto
                         4. Uscita
                         """);
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomefile1, nomefile2;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            int scelta;
            
            System.out.print("Nome file scaffali: ");
            nomefile1 = bf.readLine();
            s.caricascaffali(nomefile1);
            System.out.print("Nome file libri: ");
            nomefile2 = bf.readLine();
            s.caricalibri(nomefile2);
            
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        System.out.print("Autore: ");
                        String autore = bf.readLine();
                        System.out.print("Data (aaaammgg)");
                        String data = bf.readLine();
                        s.stampalibri(autore, data);
                        break;
                    case 2:
                        System.out.print("Prezzo: ");
                        float prezzo = Float.parseFloat(bf.readLine());
                        s.eliminalibri(prezzo);
                        break;
                    case 3:
                        s.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente nel menu");
                }
            }
        }catch(Exception e){
        }
    }
    
}
