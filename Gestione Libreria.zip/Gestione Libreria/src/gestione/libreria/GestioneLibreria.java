/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.libreria;

/**
 *
 * @author pagli
 */
public class GestioneLibreria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scaffali s = new Scaffali();
        ThreadInterattivo ti = new ThreadInterattivo(s);
        ThreadReport tr = new ThreadReport(s);
        
        tr.setDaemon(true);
        ti.start();
        tr.start();
    }
    
}
