/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.libreria;

/**
 *
 * @author pagli
 */
public class NoLibriEliminati extends Exception {
    
}
