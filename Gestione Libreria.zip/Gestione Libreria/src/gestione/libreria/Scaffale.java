/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.libreria;

import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Scaffale {
    private String tema;
    private String descrizione;
    private float sconto;
    private LinkedList<Libro> listalibri;

    public Scaffale(String tema, String descrizione, float sconto) {
        this.tema = tema;
        this.descrizione = descrizione;
        this.sconto = sconto;
        listalibri = new LinkedList<Libro>();
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getSconto() {
        return sconto;
    }

    public void setSconto(float sconto) {
        this.sconto = sconto;
    }
    
    public void addLibro(Libro l){
        listalibri.add(l);
    }
    
    public int libri(String autore, String data){
        int totale = 0;
        for(Libro l: listalibri){
            if(l.getAutore().equals(autore) && l.getDatapubblicazione().compareTo(data) > 0)
                totale++;
        }
        return totale;
    }
    
    public int eliminalibro(float prezzo){
        int conta = 0;
        for(Iterator<Libro> it = listalibri.iterator(); it.hasNext();){
            if(it.next().getPrezzo() == prezzo){
                it.remove();
                conta++;
            }
        }
        return conta;
    }
    
    public float prezzolibri(){
        float somma = 0.0F;
        float prezzoscontato = 0.0F;
        for(Libro l: listalibri){
            prezzoscontato = l.getPrezzo() - sconto*l.getPrezzo()/100;
            somma += prezzoscontato;
        }
        return somma;
    }

    @Override
    public String toString() {
        return "Scaffale{" + "tema=" + tema + ", descrizione=" + descrizione + ", sconto=" + sconto + '}';
    }
    
    
}
