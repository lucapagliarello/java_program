/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessionaria;

/**
 *
 * @author pagli
 */
public class Cliente {
    private String cf;
    private String nome;
    private String dataAcquisto;
    private float sconto;

    public Cliente(String cf, String nome, String dataAcquisto, float sconto) {
        this.cf = cf;
        this.nome = nome;
        this.dataAcquisto = dataAcquisto;
        this.sconto = sconto;
    }

    public String getCf() {
        return cf;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDataAcquisto() {
        return dataAcquisto;
    }

    public void setDataAcquisto(String dataAcquisto) {
        this.dataAcquisto = dataAcquisto;
    }

    public float getSconto() {
        return sconto;
    }

    public void setSconto(float sconto) {
        this.sconto = sconto;
    }

    @Override
    public String toString() {
        return "Cliente{" + "cf=" + cf + ", nome=" + nome + ", dataAcquisto=" + dataAcquisto + ", sconto=" + sconto + '}';
    }
    
    
}
