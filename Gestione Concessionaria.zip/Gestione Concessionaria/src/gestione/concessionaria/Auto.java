/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessionaria;

import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class Auto {
    private String modello;
    private int id;
    private String marca;
    private float prezzo;
    private LinkedList<Cliente> listaClienti;

    public Auto(String modello, int id, String marca, float prezzo) {
        this.modello = modello;
        this.id = id;
        this.marca = marca;
        this.prezzo = prezzo;
        listaClienti = new LinkedList<>();
    }

    public String getModello() {
        return modello;
    }

    public void setModello(String modello) {
        this.modello = modello;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }
    
    public void addCliente(Cliente c){
        listaClienti.add(c);
    }

    public LinkedList<Cliente> getListaClienti() {
        return listaClienti;
    }
    
    
    
    public boolean isCliente(String cf){
        for(Cliente c: listaClienti){
            if(c.getCf().equals(cf))
                return true;
        }
        return false;
    }
    
    public float applicaSconto(float prezzo){
        float nuovoPrezzo = 0.0F;
        for(Cliente c: listaClienti){
            nuovoPrezzo -= prezzo * c.getSconto()/100;
        }
        return nuovoPrezzo;
    }

    @Override
    public String toString() {
        return "Auto{" + "modello=" + modello + ", id=" + id + ", marca=" + marca + ", prezzo=" + prezzo + '}';
    }
    
    
}
