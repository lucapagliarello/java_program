/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessionaria;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private ListaAuto a;

    public ThreadReport(ListaAuto a) {
        this.a = a;
    }
    
    public void run(){
        try{
            while(true){
                a.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
