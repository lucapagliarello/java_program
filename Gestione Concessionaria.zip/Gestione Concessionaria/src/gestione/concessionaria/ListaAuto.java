/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessionaria;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.LinkedList;

/**
 *
 * @author pagli
 */
public class ListaAuto {
    private LinkedList<Auto> elencoAuto;
    private String clienteMax;
    
    public ListaAuto(){
        elencoAuto = new LinkedList<>();
    }
    
    public synchronized void caricamodelli(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String modello;
            int id;
            String marca;
            float prezzo;
            
            modello = bf.readLine();
            while(modello != null){
                id = Integer.parseInt(bf.readLine());
                marca = bf.readLine();
                prezzo = Float.parseFloat(bf.readLine());
                
                elencoAuto.add(new Auto(modello, id, marca, prezzo));
                modello = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void caricaclienti(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            int id;
            String cf;
            String nome;
            String dataAcquisto;
            float sconto;
            
            id = Integer.parseInt(bf.readLine());
            while(id != 0){
                cf = bf.readLine();
                nome = bf.readLine();
                dataAcquisto = bf.readLine();
                sconto = Float.parseFloat(bf.readLine());
                
                for(Auto a: elencoAuto){
                    if(a.getId() == id){
                        a.addCliente(new Cliente(cf, nome, dataAcquisto, sconto));
                    }
                }
                id = Integer.parseInt(bf.readLine());
            }
            bf.close();
        }catch(Exception e){
        }
    }
    
    public synchronized void vendiauto(int codice){
        for(Auto a: elencoAuto){
            if(a.getId() == codice){
                String cf;
                String nome;
                String dataAcquisto;
                float sconto;
                BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
                try {
                    System.out.print("Codice Fiscale: ");
                    cf = bf.readLine();
                    System.out.print("Nome: ");
                    nome = bf.readLine();
                    System.out.print("Data di Acquisto (aaaammgg): ");
                    dataAcquisto = bf.readLine();
                    System.out.print("Sconto personale in %: ");
                    sconto = Float.parseFloat(bf.readLine());
                    
                    a.addCliente(new Cliente(cf, nome, dataAcquisto, sconto));
                    break;
                }catch(Exception e){
                }
            }   
        }
    }
    
    public synchronized void costisostenuti(String cf){
        float somma = 0.0F;
        for(Auto a: elencoAuto){
            if(a.isCliente(cf))
                somma += a.applicaSconto(a.getPrezzo());
        }
        System.out.println("Costi sostenuti dal cliente inserito: " + somma);
    }
    
    public synchronized void generaReport(){
        float max = 0.0F;
        for(Auto a: elencoAuto){
            for(Cliente c: a.getListaClienti()){
                if(c.getSconto() > max){
                max = c.getSconto();
                clienteMax = c.getNome();
                }
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Cliente con maggiore sconto: " + clienteMax);
    }
}
