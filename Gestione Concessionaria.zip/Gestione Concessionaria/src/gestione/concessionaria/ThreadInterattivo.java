/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.concessionaria;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    private ListaAuto a;

    public ThreadInterattivo(ListaAuto a) {
        this.a = a;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("""
                         MENU
                         1. Vendi un'auto ad un cliente
                         2. Stampa la somma dei costi sostenuti da un cliente dalle auto acquistate
                         3. Stampa il cliente che ha ricevuto il maggiore sconto
                         4. Uscita
                         """);
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            String nomeFile;
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            int scelta;
            
            System.out.print("Nome file Auto: ");
            nomeFile = bf.readLine();
            a.caricamodelli(nomeFile);
            
            System.out.print("Nome file Clienti: ");
            nomeFile = bf.readLine();
            a.caricaclienti(nomeFile);      
            
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        int codice;
                        System.out.print("Codice id modello auto: ");
                        codice = Integer.parseInt(bf.readLine());
                        a.vendiauto(codice);
                        break;
                    case 2:
                        String cf;
                        System.out.print("Codice fiscale cliente: ");
                        cf = bf.readLine();
                        a.costisostenuti(cf);
                        break;
                    case 3:
                        a.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente in elenco");
                }
            }
        }catch(Exception e){
        }
    }
}
