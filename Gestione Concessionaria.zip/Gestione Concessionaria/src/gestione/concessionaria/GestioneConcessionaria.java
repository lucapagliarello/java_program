/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.concessionaria;

/**
 *
 * @author pagli
 */
public class GestioneConcessionaria {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaAuto a = new ListaAuto();
        ThreadInterattivo ti = new ThreadInterattivo(a);
        ThreadReport tr = new ThreadReport(a);
        
        tr.setDaemon(true);
        ti.start();
        tr.start();
    }
    
}
