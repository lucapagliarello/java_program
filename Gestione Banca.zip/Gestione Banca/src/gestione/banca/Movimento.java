/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.banca;

/**
 *
 * @author pagli
 */
public class Movimento {
    private int tipologia;
    private String descrizione;
    private float importo;
    private String data;

    public Movimento(int tipologia, String descrizione, float importo, String data) {
        this.tipologia = tipologia;
        this.descrizione = descrizione;
        this.importo = importo;
        this.data = data;
    }

    public int getTipologia() {
        return tipologia;
    }

    public void setTipologia(int tipologia) {
        this.tipologia = tipologia;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getImporto() {
        return importo;
    }

    public void setImporto(float importo) {
        this.importo = importo;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "Movimento{" + "tipologia=" + tipologia + ", descrizione=" + descrizione + ", importo=" + importo + ", data=" + data + '}';
    }
    
    
}
