/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.banca;

/**
 *
 * @author pagli
 */
public class ThreadReport extends Thread {
    private ListaClienti l;

    public ThreadReport(ListaClienti l) {
        this.l = l;
    }
    
    public void run(){
        try{
            while(true){
                l.generaReport();
                Thread.sleep(5000);
            }
        }catch(InterruptedException e){
        }
    }
    
}
