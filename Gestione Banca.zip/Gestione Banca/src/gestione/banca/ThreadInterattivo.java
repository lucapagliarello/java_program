/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.banca;
import java.io.*;
/**
 *
 * @author pagli
 */
public class ThreadInterattivo extends Thread {
    ListaClienti l;

    public ThreadInterattivo(ListaClienti l) {
        this.l = l;
    }
    
    public int menu(BufferedReader bf){
        int scelta = -1;
        System.out.print("MENU\n" +
                "1. Elimina i movimenti realizzati da un cliente in una certa data\n" +
                "2. Stampa tutti i clienti che hanno realizzato un certo valore di addebiti in una certa data\n" +
                "3. Stampa il cliente con il maggiore numero di accrediti che superano i 5000 euro\n" +
                "4. Uscita\n");
        try{
            scelta = Integer.parseInt(bf.readLine());
        }catch(Exception e){
        }
        return scelta;
    }
    
    public void run(){
        try{
            BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
            String nomeFile;
            int scelta;
            int numerofiliale;
            System.out.print("File dei clienti della banca: ");
            nomeFile = bf.readLine();
            System.out.print("Inserisci il numero della filiale da dover considerare: ");
            numerofiliale = Integer.parseInt(bf.readLine());
            l.caricaclienti(nomeFile, numerofiliale);
            System.out.print("File dei movimenti: ");
            nomeFile = bf.readLine();
            l.caricamovimenti(nomeFile);
            
            while((scelta = menu(bf)) != 4){
                switch(scelta){
                    case 1:
                        System.out.print("IBAN: ");
                        String IBAN = bf.readLine();
                        System.out.print("Data: ");
                        String data = bf.readLine();
                        l.eliminamovimenti(IBAN, data);
                        break;
                    case 2:
                        System.out.print("Inserire importo X: ");
                        float importoX = Float.parseFloat(bf.readLine());
                        System.out.print("Inserire data D: ");
                        String dataD = bf.readLine();
                        l.stampaclienti(importoX, dataD);
                        break;
                    case 3:
                        l.stampaReport();
                        break;
                    case 4:
                        return;
                    default:
                        System.out.println("Voce non presente nel menu");
                }
            }
        }catch(Exception e){
        }
    }
}
