/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.banca;
import java.util.*;
/**
 *
 * @author pagli
 */
public class Clienti {
    private String IBAN;
    private int numFiliale;
    private String nome;
    private float saldo;
    private LinkedList<Movimento> listaMovimenti;

    public Clienti(String IBAN, int numFiliale, String nome, float saldo) {
        this.IBAN = IBAN;
        this.numFiliale = numFiliale;
        this.nome = nome;
        this.saldo = saldo;
        listaMovimenti = new LinkedList();
    }

    public String getIBAN() {
        return IBAN;
    }

    public void setIBAN(String IBAN) {
        this.IBAN = IBAN;
    }

    public int getNumFiliale() {
        return numFiliale;
    }

    public void setNumFiliale(int numFiliale) {
        this.numFiliale = numFiliale;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    
    public void addMovimento(Movimento m){
        listaMovimenti.add(m);
    }
    
    public int eliminamovimenti(String IBAN, String data){
        int cont = 0;
        if(this.IBAN.equals(IBAN)){
            for(Iterator<Movimento> it = listaMovimenti.iterator(); it.hasNext();){
                Movimento mov = it.next();
                if(mov.getData().equals(data)){
                    saldo -= mov.getImporto();
                    it.remove();
                    cont++;
                }
            }
        }
        return cont;
    }
    
    public float numaddebiti(String data){
        float somma = 0.0F;
        for(Movimento m: listaMovimenti){
            if(m.getData().equals(data) && m.getTipologia() == 0)
                somma += m.getImporto();
        }
        return somma;
    }
    
    public int numaccrediti(){
        int cont = 0;
        for(Movimento m: listaMovimenti){
            if(m.getImporto() > 5000 && m.getTipologia() == 1)
                cont++;
        }
        return cont;
    }

    @Override
    public String toString() {
        return "Clienti{" + "IBAN=" + IBAN + ", numFiliale=" + numFiliale + ", nome=" + nome + ", saldo=" + saldo + '}';
    }
    

    
    
}
