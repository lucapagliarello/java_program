/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.banca;
import java.util.*;
import java.io.*;
/**
 *
 * @author pagli
 */
public class ListaClienti {
    private LinkedList<Clienti> listaClienti;
    String ClienteMax;

    public ListaClienti() {
        listaClienti = new LinkedList();
    }
    
    public synchronized void caricaclienti(String nomefile, int numerofiliale){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            String IBAN;
            int numFiliale;
            String nome;
            float saldo;
            
            IBAN = bf.readLine();
            while(IBAN != null){
                numFiliale = Integer.parseInt(bf.readLine());
                nome = bf.readLine();
                saldo = Float.parseFloat(bf.readLine());
                
                if(numFiliale == numerofiliale)
                    listaClienti.add(new Clienti(IBAN, numFiliale, nome, saldo));
                
                IBAN = bf.readLine();
            }
            bf.close();
        }catch(Exception e){
        }
    }

    public synchronized void caricamovimenti(String nomefile){
        try{
            BufferedReader bf = new BufferedReader(new FileReader(nomefile));
            int tipologia;
            String descrizione;
            String IBAN;
            float importo;
            String data;
            
            tipologia = Integer.parseInt(bf.readLine());
            while(tipologia == 0 || tipologia == 1){
                descrizione = bf.readLine();
                IBAN = bf.readLine();
                importo = Float.parseFloat(bf.readLine());
                data = bf.readLine();
                
                for(Clienti c: listaClienti){
                    if(c.getIBAN().equals(IBAN)){
                        c.addMovimento(new Movimento(tipologia, descrizione, importo, data));
                        break;
                    }
                }
            }
        }catch(Exception e){
        }
    }    
    
    public synchronized void eliminamovimenti(String IBAN, String data) throws NoMovimenti{
        int cont = 0;
        float nuovosaldo = 0.0F;
        for(Clienti c: listaClienti){
            cont += c.eliminamovimenti(IBAN, data);
            nuovosaldo = c.getSaldo();
        }
                        
        if(cont == 0)
            throw new NoMovimenti();
        
        System.out.println("Nuovo saldo= " + nuovosaldo);

    }
    
    public synchronized void stampaclienti(float importo, String data){
        for(Clienti c: listaClienti){
            if(c.numaddebiti(data) > importo)
                System.out.println(c.getNome());
        }
    }
    
    public synchronized void generaReport(){
        int max = 0;
        
        for(Clienti c: listaClienti){
            if(c.numaccrediti() > max){
                max = c.numaccrediti();
                ClienteMax = c.getNome();
            }
        }
    }
    
    public synchronized void stampaReport(){
        System.out.println("Il cliente con il maggiore numero di accrediti e': " + ClienteMax);
    }
    
}
