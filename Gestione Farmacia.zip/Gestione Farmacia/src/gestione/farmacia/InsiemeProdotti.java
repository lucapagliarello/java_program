/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.farmacia;

/**
 *
 * @author pagli
 */
public class InsiemeProdotti {
    public GenericProduct prod;
    public int numpezzi;

    public InsiemeProdotti(GenericProduct prod, int numpezzi) {
        this.prod = prod;
        this.numpezzi = numpezzi;
    }
    
    public int getNumpezzi() {
        return numpezzi;
    }

    public void setNumpezzi(int numpezzi) {
        this.numpezzi = numpezzi;
    }

    @Override
    public String toString() {
        return "InsiemeProdotti{" + "prod=" + prod + ", numpezzi=" + numpezzi + '}';
    } 
}
