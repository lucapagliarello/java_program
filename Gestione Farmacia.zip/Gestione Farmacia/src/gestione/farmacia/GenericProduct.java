/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.farmacia;

/**
 *
 * @author pagli
 */
public class GenericProduct {
    private String nome;
    private float prezzo;

    public GenericProduct(String nome, float prezzo) {
        this.nome = nome;
        this.prezzo = prezzo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    @Override
    public String toString() {
        return "GenericProduct{" + "nome=" + nome + " - prezzo=" + prezzo + '}';
    }
    
    public int compareTo(Object o){
        return (int)(prezzo - ((GenericProduct)o).prezzo);
    }
}
