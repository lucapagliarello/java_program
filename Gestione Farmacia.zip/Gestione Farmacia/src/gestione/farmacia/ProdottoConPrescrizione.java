/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.farmacia;

/**
 *
 * @author pagli
 */
public class ProdottoConPrescrizione extends GenericProduct {
    private String categoria;
    private int dimensione;
    private String tiporicetta;

    public ProdottoConPrescrizione(String categoria, int dimensione, String tiporicetta, String nome, float prezzo) {
        super(nome, prezzo);
        this.categoria = categoria;
        this.dimensione = dimensione;
        this.tiporicetta = tiporicetta;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getDimensione() {
        return dimensione;
    }

    public void setDimensione(int dimensione) {
        this.dimensione = dimensione;
    }

    public String getTiporicetta() {
        return tiporicetta;
    }

    public void setTiporicetta(String tiporicetta) {
        this.tiporicetta = tiporicetta;
    }

    @Override
    public String toString() {
        return "ProdottoConPrescrizione{" + super.toString() + "categoria=" + categoria + '}';
    }
    
    public boolean equals(Object o){
        return getNome().equals(((ProdottoConPrescrizione)o).getNome());
    }
}
