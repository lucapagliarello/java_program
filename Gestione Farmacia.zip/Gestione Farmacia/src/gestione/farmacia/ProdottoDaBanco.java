/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.farmacia;

/**
 *
 * @author pagli
 */
public class ProdottoDaBanco extends GenericProduct {
    private String tipologia;
    private int dimensionestock;

    public ProdottoDaBanco(String tipologia, int dimensionestock, String nome, float prezzo) {
        super(nome, prezzo);
        this.tipologia = tipologia;
        this.dimensionestock = dimensionestock;
    }

    public String getTipologia() {
        return tipologia;
    }

    public void setTipologia(String tipologia) {
        this.tipologia = tipologia;
    }

    public int getDimensionestock() {
        return dimensionestock;
    }

    public void setDimensionestock(int dimensionestock) {
        this.dimensionestock = dimensionestock;
    }

    @Override
    public String toString() {
        return "ProdottoDaBanco{" + super.toString() + "tipologia=" + tipologia + '}';
    }
    
    public boolean equals(Object o){
        return getNome().equals(((ProdottoDaBanco)o).getNome());
    }
    
}
