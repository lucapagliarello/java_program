/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestione.farmacia;

/**
 *
 * @author pagli
 */
public class Store {
    InsiemeProdotti[] prodotti;
    int numprodotti;

    public Store(int N) {
        prodotti = new InsiemeProdotti[N];
        numprodotti = 0;
    }

    public int getNumprodotti() {
        return numprodotti;
    }

    public void setNumprodotti(int numprodotti) {
        this.numprodotti = numprodotti;
    }
    
    public void addProduct(GenericProduct p, int numpezzi) throws MagazzinoPienoException {
        if(prodotti.length == numprodotti)
            throw new MagazzinoPienoException();
        prodotti[numprodotti] = new InsiemeProdotti(p, numpezzi);
        numprodotti++;
    }
    
    public void removeProduct(String nome){
        for(int i=0; i<numprodotti; i++){
            if(prodotti[i].prod.getNome().equals(nome)){
                prodotti[i] = prodotti[numprodotti - 1];
                prodotti[numprodotti - 1] = null;
                numprodotti--;
                return;
            }
        }
        System.out.println("Prodotto non trovato nel magazzino.");
    }
    
    public void modifyProduct(String nome, int numpezzi){
        for(int i=0; i<numprodotti; i++){
            if(prodotti[i].prod.getNome().equals(nome)){
                prodotti[i].numpezzi = numpezzi;
                return;
            }
        }
        System.out.println("Prodotto non trovato nello store.");
    }
    
    public int cercaProduct(String nome){
        for(int i=0; i<numprodotti; i++){
            if(prodotti[i].prod.getNome().equals(nome))
                return prodotti[i].numpezzi;
        }
        return 0;
    }

    @Override
    public String toString() {
        String s = "";
        for(int i=0; i<numprodotti; i++){
            s = s + prodotti[i] + "\n";
        }
        return s;
    }
}
