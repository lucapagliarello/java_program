/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestione.farmacia;
import java.io.*;

/**
 *
 * @author pagli
 */
public class GestioneFarmacia {
    
    public static int menu(BufferedReader bf) throws Exception{
        int scelta;
        System.out.println("MENU\n");
        System.out.println("1. Crea un magazzino\n");
        System.out.println("2. Inserire un nuovo prodotto\n");
        System.out.println("3. Vendere un prodotto\n");
        System.out.println("4. Stampa l'elenco dei prodotti presenti in magazzino\n");
        System.out.println("5. Uscita\n");
        scelta = Integer.parseInt(bf.readLine());
        return scelta;
    }
    
    public static Store creamagazzino(BufferedReader bf) throws Exception{
        Store magazzino;
        int dim;
        
        System.out.println("Inserisci la dimensione del magazzino: ");
        dim = Integer.parseInt(bf.readLine());
        magazzino = new Store(dim);
        return magazzino;
    }
    
    public static void inserisciprodotto(BufferedReader bf, Store magazzino) throws Exception {
        System.out.println("Nome: ");
        String nome = bf.readLine();
        System.out.println("Prezzo: ");
        float prezzo = Float.parseFloat(bf.readLine());
        System.out.println("Numero di pezzi: ");
        int numpezzi = Integer.parseInt(bf.readLine());
        System.out.println("Digita: 0 per inserire un prodotto da banco, 1 per un prodotto con prescrizione");
        int scelta = Integer.parseInt(bf.readLine());
        if(scelta == 0){
            System.out.println("Tipologia: ");
            String tipo = bf.readLine();
            System.out.println("Dimensione stock: ");
            int dim = Integer.parseInt(bf.readLine());
            magazzino.addProduct(new ProdottoDaBanco(nome, (int)prezzo, tipo, dim), numpezzi);
        } else if(scelta == 1){
            System.out.println("Tipologia: ");
            String tipo = bf.readLine();
            System.out.println("Dimensione stock: ");
            int dim = Integer.parseInt(bf.readLine());
            System.out.println("Tipo di ricetta: ");
            String ricetta = bf.readLine();
            magazzino.addProduct(new ProdottoConPrescrizione(tipo, dim, ricetta, nome, prezzo), numpezzi);
        }
    }
    
    public static void vendereprodotto(BufferedReader bf, Store magazzino) throws Exception {
        System.out.println("Nome: ");
        String nome = bf.readLine();
        System.out.println("Quantita' da vendere: ");
        int quantita = Integer.parseInt(bf.readLine());
        int numpezzi = magazzino.cercaProduct(nome);
        if(quantita < numpezzi)
            magazzino.modifyProduct(nome, numpezzi - quantita);
        else
            System.out.println("Numero di prodotti richiesti non presente in magazzino");
    }

    /**
     * @param args the command line arguments
     */

    /**
     *
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        Store magazzino = null;
        int scelta = 0;
        BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        
        while((scelta = menu(bf)) != 5){
            switch(scelta){
                case 1:
                    if(magazzino == null)
                        magazzino = creamagazzino(bf);
                    break;
                case 2:
                    inserisciprodotto(bf, magazzino);
                    break;
                case 3:
                    vendereprodotto(bf, magazzino);
                    break;
                case 4:
                    System.out.println(magazzino);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Voce non presente.");
            }
        }
        
    }
    
}
